# -*- coding: utf-8 -*-
"""
@Time ： 2021/12/25 12:08
@Auth ： wongbooming
@File ：test_many_weights.py
@Explain :
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

import os
import cv2
import numpy as np
from progress.bar import Bar
import torch

from lib.opts import opts
from lib.logger import Logger
from lib.utils.utils import AverageMeter
from lib.datasets.dataset_factory import dataset_factory
from lib.detectors.detector_factory import detector_factory
import cv2
import numpy as np
from progress.bar import Bar
import time
import torch, tensorboardX

from models.model import create_model, load_model
from utils.image import get_affine_transform
from utils.debugger import Debugger

from nms_torch.nms import soft_nms as soft_nms_39
# from external.nms import soft_nms_39
from models.decode import circle_multi_pose_decode
from models.utils import flip_tensor, flip_lr_off, flip_lr
from utils.image import get_affine_transform
from utils.post_process import circle_multi_pose_post_process
from utils.debugger import Debugger


class PrefetchDataset(torch.utils.data.Dataset):
    def __init__(self, opt, dataset, pre_process_func):
        self.images = dataset.images
        self.load_image_func = dataset.coco.loadImgs
        self.img_dir = dataset.img_dir
        self.pre_process_func = pre_process_func
        self.opt = opt

    def __getitem__(self, index):
        img_id = self.images[index]
        img_info = self.load_image_func(ids=[img_id])[0]
        img_path = os.path.join(self.img_dir, img_info['file_name'])
        image = cv2.imread(img_path)
        images, meta = {}, {}
        for scale in opt.test_scales:
            if opt.task == 'ddd':
                images[scale], meta[scale] = self.pre_process_func(
                    image, scale, img_info['calib'])
            else:
                images[scale], meta[scale] = self.pre_process_func(image, scale)
        return img_id, {'images': images, 'image': image, 'meta': meta}

    def __len__(self):
        return len(self.images)


class every_BaseDetector():
    def __init__(self, opt, weights):
        if opt.gpus[0] >= 0:
            opt.device = torch.device('cuda')
        else:
            opt.device = torch.device('cpu')

        print('Creating model...')
        self.model = create_model(opt.arch, opt.heads, opt.head_conv)
        self.model = load_model(self.model, weights)
        self.model = self.model.to(opt.device)
        self.model.eval()

        self.mean = np.array(opt.mean, dtype=np.float32).reshape(1, 1, 3)
        self.std = np.array(opt.std, dtype=np.float32).reshape(1, 1, 3)
        self.max_per_image = 100
        self.num_classes = opt.num_classes
        self.scales = opt.test_scales
        self.opt = opt
        self.pause = True

    def pre_process(self, image, scale, meta=None):
        height, width = image.shape[0:2]
        new_height = int(height * scale)
        new_width = int(width * scale)
        if self.opt.fix_res:
            inp_height, inp_width = self.opt.input_h, self.opt.input_w
            c = np.array([new_width / 2., new_height / 2.], dtype=np.float32)
            s = max(height, width) * 1.0
        else:
            inp_height = (new_height | self.opt.pad) + 1
            inp_width = (new_width | self.opt.pad) + 1
            c = np.array([new_width // 2, new_height // 2], dtype=np.float32)
            s = np.array([inp_width, inp_height], dtype=np.float32)

        trans_input = get_affine_transform(c, s, 0, [inp_width, inp_height])
        resized_image = cv2.resize(image, (new_width, new_height))
        inp_image = cv2.warpAffine(
            resized_image, trans_input, (inp_width, inp_height),
            flags=cv2.INTER_LINEAR)
        inp_image = ((inp_image / 255. - self.mean) / self.std).astype(np.float32)

        images = inp_image.transpose(2, 0, 1).reshape(1, 3, inp_height, inp_width)
        if self.opt.flip_test:
            images = np.concatenate((images, images[:, :, :, ::-1]), axis=0)
        images = torch.from_numpy(images)
        meta = {'c': c, 's': s,
                'out_height': inp_height // self.opt.down_ratio,
                'out_width': inp_width // self.opt.down_ratio}
        return images, meta

    def process(self, images, return_time=False):
        with torch.no_grad():
            torch.cuda.synchronize()
            output = self.model(images)[-1]
            output['hm'] = output['hm'].sigmoid_()
            if self.opt.hm_hp and not self.opt.mse_loss:
                output['hm_hp'] = output['hm_hp'].sigmoid_()

            reg = output['reg'] if self.opt.reg_offset else None
            hm_hp = output['hm_hp'] if self.opt.hm_hp else None
            hp_offset = output['hp_offset'] if self.opt.reg_hp_offset else None
            torch.cuda.synchronize()
            forward_time = time.time()

            if self.opt.flip_test:
                output['hm'] = (output['hm'][0:1] + flip_tensor(output['hm'][1:2])) / 2
                # output['wh'] = (output['wh'][0:1] + flip_tensor(output['wh'][1:2])) / 2
                output['radius'] = (output['radius'][0:1] + flip_tensor(output['radius'][1:2])) / 2

                output['hps'] = (output['hps'][0:1] +
                                 flip_lr_off(output['hps'][1:2], self.flip_idx)) / 2
                hm_hp = (hm_hp[0:1] + flip_lr(hm_hp[1:2], self.flip_idx)) / 2 \
                    if hm_hp is not None else None
                reg = reg[0:1] if reg is not None else None
                hp_offset = hp_offset[0:1] if hp_offset is not None else None

            dets = circle_multi_pose_decode(
                output['hm'], output['radius'], output['hps'],
                reg=reg, hm_hp=hm_hp, hp_offset=hp_offset, K=self.opt.K)

        if return_time:
            return output, dets, forward_time
        else:
            return output, dets

    def post_process(self, dets, meta, scale=1):
        dets = dets.detach().cpu().numpy().reshape(1, -1, dets.shape[2])
        dets = circle_multi_pose_post_process(
            dets.copy(), [meta['c']], [meta['s']],
            meta['out_height'], meta['out_width'])
        for j in range(1, self.num_classes + 1):
            dets[0][j] = np.array(dets[0][j], dtype=np.float32).reshape(-1, 11)
            # import pdb; pdb.set_trace()
            dets[0][j][:, :3] /= scale
            dets[0][j][:, 4:] /= scale
        return dets[0]

    def merge_outputs(self, detections):
        results = {}
        results[1] = np.concatenate(
            [detection[1] for detection in detections], axis=0).astype(np.float32)
        if self.opt.nms or len(self.opt.test_scales) > 1:
            soft_nms_39(results[1], Nt=0.5, method=2)
        results[1] = results[1].tolist()
        return results

    def debug(self, debugger, images, dets, output, scale=1):
        dets = dets.detach().cpu().numpy().copy()
        dets[:, :, :3] *= self.opt.down_ratio
        dets[:, :, 4:10] *= self.opt.down_ratio
        img = images[0].detach().cpu().numpy().transpose(1, 2, 0)
        img = np.clip(((
                               img * self.std + self.mean) * 255.), 0, 255).astype(np.uint8)
        pred = debugger.gen_colormap(output['hm'][0].detach().cpu().numpy())
        debugger.add_blend_img(img, pred, 'pred_hm')
        if self.opt.hm_hp:
            pred = debugger.gen_colormap_hp(
                output['hm_hp'][0].detach().cpu().numpy())
            debugger.add_blend_img(img, pred, 'pred_hmhp')

    def show_results(self, debugger, image, results, image_name):
        debugger.add_img(image, img_id='circle_multi_pose')
        for circle in results[1]:
            if circle[3] > self.opt.vis_thresh:
                debugger.add_coco_circle(circle[:3], circle[-1], circle[3], img_id='circle_multi_pose')
                debugger.add_coco_hp(circle[4:10], img_id='circle_multi_pose')
        # debugger.show_all_imgs(pause=self.pause)
        debugger.save_all_imgs(path=self.opt.demo_dir, prefix='predict_res18_bc_hp_', genID=False, name_id=image_name)

    def run(self, image_or_path_or_tensor, ind, meta=None):
        load_time, pre_time, net_time, dec_time, post_time = 0, 0, 0, 0, 0
        merge_time, tot_time = 0, 0
        debugger = Debugger(dataset=self.opt.dataset, ipynb=(self.opt.debug == 3),
                            theme=self.opt.debugger_theme)
        start_time = time.time()
        pre_processed = False
        if isinstance(image_or_path_or_tensor, np.ndarray):
            image = image_or_path_or_tensor
        elif type(image_or_path_or_tensor) == type(''):
            image = cv2.imread(image_or_path_or_tensor)
        else:
            image = image_or_path_or_tensor['image'][0].numpy()
            pre_processed_images = image_or_path_or_tensor
            pre_processed = True

        loaded_time = time.time()
        load_time += (loaded_time - start_time)

        detections = []
        for scale in self.scales:
            scale_start_time = time.time()
            if not pre_processed:
                images, meta = self.pre_process(image, scale, meta)
            else:
                # import pdb; pdb.set_trace()
                images = pre_processed_images['images'][scale][0]
                meta = pre_processed_images['meta'][scale]
                meta = {k: v.numpy()[0] for k, v in meta.items()}
            images = images.to(self.opt.device)
            torch.cuda.synchronize()
            pre_process_time = time.time()
            pre_time += pre_process_time - scale_start_time

            output, dets, forward_time = self.process(images, return_time=True)

            torch.cuda.synchronize()
            net_time += forward_time - pre_process_time
            decode_time = time.time()
            dec_time += decode_time - forward_time

            if self.opt.debug >= 2:
                self.debug(debugger, images, dets, output, scale)

            dets = self.post_process(dets, meta, scale)
            torch.cuda.synchronize()
            post_process_time = time.time()
            post_time += post_process_time - decode_time

            detections.append(dets)

        results = self.merge_outputs(detections)
        torch.cuda.synchronize()
        end_time = time.time()
        merge_time += end_time - post_process_time
        tot_time += end_time - start_time

        # 保存的图像次序名字为

        image_name = str(ind)

        # if self.opt.debug >= 1:
        # 保存结果
        self.show_results(debugger, image, results, image_name)

        return {'results': results, 'tot': tot_time, 'load': load_time,
                'pre': pre_time, 'net': net_time, 'dec': dec_time,
                'post': post_time, 'merge': merge_time}

def prefetch_test(opt):

    os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpus_str
    writer = tensorboardX.SummaryWriter(log_dir=r'E:\trainingrecords\circlenet\on_train\circle_multi_pose\bc_circle_hp_res50_nofpn_keypoints_order')
    Dataset = dataset_factory[opt.dataset]
    opt = opts().update_dataset_info_and_set_heads(opt, Dataset)
    # print(opt)
    Logger(opt)
    # Detector = detector_factory[opt.task]
    split = 'val'
    dataset = Dataset(opt, split)
    # 下面开始分权重进行检测
    weights = []
    path = r'E:\trainingrecords\circlenet\on_train\circle_multi_pose\bc_circle_hp_res50_nofpn_keypoints_order'
    for name in os.listdir(path):
        if name.endswith('.pth'):
            weights.append(name)
        else:
            pass
    for each_weight in weights:
        print('*'*40)
        epoch = int((each_weight.split('model_')[-1]).split('.')[0])
        print('epoch:', epoch)
        this_weight_path = path + '/' + each_weight
        print(this_weight_path)
        detector = every_BaseDetector(opt, this_weight_path)
        data_loader = torch.utils.data.DataLoader(
            PrefetchDataset(opt, dataset, detector.pre_process),
            batch_size=1, shuffle=False, num_workers=0, pin_memory=True)
        results = {}
        num_iters = len(dataset)
        bar = Bar('{}'.format(opt.exp_id), max=num_iters)
        time_stats = ['tot', 'load', 'pre', 'net', 'dec', 'post', 'merge']
        avg_time_stats = {t: AverageMeter() for t in time_stats}
        for ind, (img_id, pre_processed_images) in enumerate(data_loader):
            # 为了测试froc，因此减少总的数据长度，加快推理速度
            # if ind == 105:
            #     break
            # else:
            #     print('ind:', ind)
            #     pass

            # cv2.imwrite(gt_save_path + '//' + str(ind) + '.jpg', pre_processed_images['image'][0, :, :, :].numpy())
            ret = detector.run(pre_processed_images, ind)
            results[img_id.numpy().astype(np.int32)[0]] = ret['results']
            Bar.suffix = '[{0}/{1}]|Tot: {total:} |ETA: {eta:} '.format(
                ind, num_iters, total=bar.elapsed_td, eta=bar.eta_td)
            for t in avg_time_stats:
                avg_time_stats[t].update(ret[t])
                Bar.suffix = Bar.suffix + '|{} {tm.val:.3f}s ({tm.avg:.3f}s) '.format(
                    t, tm=avg_time_stats[t])
            bar.next()
        bar.finish()
        if opt.task == 'circle_multi_pose':
            f1_best, pre_best, rec_best = dataset.run_circle_train_eval(results, opt.save_dir)
            print('f1_best:', f1_best)
            print('pre_best:', pre_best)
            print('rec_best:', rec_best)

            writer.add_scalar('f1_best', f1_best, epoch)
            writer.add_scalar('pre_best', pre_best, epoch)
            writer.add_scalar('rec_best', rec_best, epoch)
            print('*'*40)
        else:
            print('任务类型有问题')
            break


if __name__ == '__main__':
    os.environ['TORCH_HOME'] = r'E:\projects_models\detect\MN_CircleBinucleus_Detection\src\weights'
    # gt_save_path = r'E:\trainingrecords\circlenet\gt\test_original_images'
    opt = opts().parse()
    prefetch_test(opt)
