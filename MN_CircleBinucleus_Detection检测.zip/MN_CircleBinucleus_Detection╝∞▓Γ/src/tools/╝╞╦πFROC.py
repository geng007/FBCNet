# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/14 16:43
@Auth ： wongbooming
@File ：计算FROC.py
@Explain :
"""
import numpy as np
from scipy import interpolate
import math, os
import fractions
import json


def f(x):
    """
    Compute  x - sin(x) cos(x)  without loss of significance
    """
    if abs(x) < 0.01:
        return 2 * x ** 3 / 3 - 2 * x ** 5 / 15 + 4 * x ** 7 / 315
    return x - math.sin(x) * math.cos(x)

def acos_sqrt(x, sgn):
    """
    Compute acos(sgn * sqrt(x)) with accuracy even when |x| is close to 1.
    http://www.wolframalpha.com/input/?i=acos%28sqrt%281-y%29%29
    http://www.wolframalpha.com/input/?i=acos%28sqrt%28-1%2By%29%29
    """
    assert isinstance(x, fractions.Fraction)

    y = 1 - x
    if y < 0.01:
        # pp('y < 0.01')
        numers = [1, 1, 3, 5, 35]
        denoms = [1, 6, 40, 112, 1152]
        ans = fractions.Fraction('0')
        for i, (n, d) in enumerate(zip(numers, denoms)):
            ans += y ** i * n / d
        assert isinstance(y, fractions.Fraction)
        ans *= math.sqrt(y)
        if sgn >= 0:
            return ans
        else:
            return math.pi - ans

    return math.acos(sgn * math.sqrt(x))

def solve(r1, r2, d_squared):
    r1, r2 = min(r1, r2), max(r1, r2)

    d = math.sqrt(d_squared)
    if d >= r1 + r2:  # circles are far apart
        return 0.0
    if r2 >= d + r1:  # whole circle is contained in the other
        return math.pi * r1 ** 2

    r1f, r2f, dsq = map(fractions.Fraction, [r1, r2, d_squared])
    r1sq, r2sq = map(lambda i: i * i, [r1f, r2f])
    numer1 = r1sq + dsq - r2sq
    cos_theta1_sq = numer1 * numer1 / (4 * r1sq * dsq)
    numer2 = r2sq + dsq - r1sq
    cos_theta2_sq = numer2 * numer2 / (4 * r2sq * dsq)
    theta1 = acos_sqrt(cos_theta1_sq, math.copysign(1, numer1))
    theta2 = acos_sqrt(cos_theta2_sq, math.copysign(1, numer2))
    result = r1 * r1 * f(theta1) + r2 * r2 * f(theta2)

    # pp("d = %.16e" % d)
    # pp("cos_theta1_sq = %.16e" % cos_theta1_sq)
    # pp("theta1 = %.16e" % theta1)
    # pp("theta2 = %.16e" % theta2)
    # pp("f(theta1) = %.16e" % f(theta1))
    # pp("f(theta2) = %.16e" % f(theta2))
    # pp("result = %.16e" % result)

    return result

def circleIOU(d,g):
    ious = np.zeros((len(d), len(g)))
    for di in range(len(d)):
        center_d_x = d[di][0]
        center_d_y = d[di][1]
        center_d_r = d[di][2]
        for gi in range(len(g)):
            center_g_x = g[gi][0]
            center_g_y = g[gi][1]
            center_g_r = g[gi][2]
            distance = math.sqrt((center_d_x - center_g_x)**2 + (center_d_y - center_g_y)**2)
            if center_d_r <=0 or center_g_r <=0 or distance > (center_d_r + center_g_r) :
                ious[di, gi] = 0
            else:
                overlap = solve(center_d_r, center_g_r, distance**2)
                union = math.pi * (center_d_r**2) + math.pi * (center_g_r**2) -  overlap
                if union == 0:
                    ious[di,gi] = 0
                else:
                    ious[di, gi] = overlap/union

            # r1 = 2
            # r2 = 2
            # dd = 2
            # oo1 = overlap_oneline(r1,r2,dd)
            #
            # oo2 = solve(r1, r2, dd ** 2)

    return ious


def circle_FROC(boxes_all, gts_all, iou_th):
    """Compute the Free ROC curve, for single class only"""
    nImg = len(boxes_all)
    img_idxs = np.hstack([[i] * len(boxes_all[i]) for i in range(nImg)]).astype(int)
    boxes_cat = np.vstack(boxes_all)
    scores = boxes_cat[:, -1]
    ord = np.argsort(scores)[::-1]
    boxes_cat = boxes_cat[ord, :4]
    img_idxs = img_idxs[ord]
    hits = [np.zeros((len(gts),), dtype=bool) for gts in gts_all]
    nHits = 0
    nMiss = 0
    tps = []
    fps = []
    for i in range(len(boxes_cat)):
        overlaps = circleIOU(boxes_cat[i, :], gts_all[img_idxs[i]])
        if len(overlaps) == 0 or overlaps.max() < iou_th:
            nMiss += 1
        else:
            for j in range(len(overlaps)):
                if overlaps[j] >= iou_th and not hits[img_idxs[i]][j]:
                    hits[img_idxs[i]][j] = True
                    nHits += 1
        tps.append(nHits)
        fps.append(nMiss)
    nGt = len(np.vstack(gts_all))
    sens = np.array(tps, dtype=float) / nGt
    fp_per_img = np.array(fps, dtype=float) / nImg
    return sens, fp_per_img


if __name__ == '__main__':
    gt_json_path = r'..\lib\data\BC\boundingbox_val.json'
    det_json_path = r'..\lib\exp\circle_multi_pose\bc_circle_hp_test\results.json'
    images_path = r'..\lib\data\BC\val'
    images_length = len(os.listdir(images_path))
    with open(gt_json_path, 'r', encoding='utf8')as fp:
        gt_data = json.load(fp)
    with open(det_json_path, 'r', encoding='utf8')as fp:
        det_data = json.load(fp)

    # gt含有的半径和圆心信息为：，一张图好几个那种情况对应的是image_id，应该写成字典的键值对比较好，键就是image_id,其它所有的都是值，值是列表集合
    gts_all = []
    ann = gt_data['annotations']
    for i in range(len(ann)):
        one_info = []
        one_info.append(ann[i]['image_id'])
        one_info.append(ann[i]['circle_radius'])
        one_info.append(ann[i]['circle_center'])
        gts_all.append(one_info)

    print(len(gts_all))
    print(gts_all)
    #  [214, 42.0, [148.0, 376.0]], [215, 36.5, [199.0, 237.5]], [215, 30.0, [470.0, 68.5]], [215, 31.0, [415.0, 421.0]],
    # 将大列表整理成小列表
    processed_gts = [[] for i in range(images_length)]
    print(processed_gts)
    for gt in gts_all:
        image_id = gt[0]
        processed_gts[image_id].append(gt[1])
        processed_gts[image_id].append(gt[2][0])
        processed_gts[image_id].append(gt[2][1])
    print(len(processed_gts))
    print(processed_gts)

    # 预测的结果，这里首先把阈值较小的直接去掉
    det_all = []
    for i in range(len(det_data)):
        # if det_data[i]['score'] >= 0.2:
        one_info = []
        one_info.append(det_data[i]['image_id'])
        one_info.append(det_data[i]['circle_radius'])
        one_info.append(det_data[i]['circle_center'])
        one_info.append(det_data[i]['score'])
        det_all.append(one_info)
    print(len(det_all))

    processed_det = [[] for i in range(images_length)]
    print(processed_det)
    for det in det_all:
        if det[3] >= 0.1:   # 直接滤除不必要计算的阈值
            image_id = det[0]
            processed_det[image_id].append(det[1])
            processed_det[image_id].append(det[2][0])
            processed_det[image_id].append(det[2][1])
            processed_det[image_id].append(det[3])

    print(len(processed_det))
    print(processed_det[10])
    print(len(processed_det[10]))

    # 写入txt文件内
    m = 0
    for gt in processed_gts:
        nums = len(gt) // 3
        with open('res_18/gts_box.txt', mode='a+') as g:
            g.write(str(m) + '\n')
            g.write(str(nums) + '\n')
        for i in range(0, len(gt), 3):
            with open('res_18/gts_box.txt', mode='a+') as g:
                g.write(str(gt[i + 1] - gt[i]) + ' ' + str(gt[i + 2] - gt[i]) +
                        ' ' + str(gt[i] * 2) + ' ' + str(gt[i] * 2) + ' 1 ' + '\n')
            # with open('res_18/gts.txt', mode='a+') as g:
            #     g.write(str(gt[i]) + ' ' + str(gt[i + 1]) + ' ' + str(gt[i + 2]) + ' ' + '\n')
        m += 1

    m = 0
    for det in processed_det:
        nums = len(det) // 4
        with open('res_18/det_box.txt', mode='a+') as g:
            g.write(str(m) + '\n')
            g.write(str(nums) + '\n')
        for i in range(0, len(det), 4):
            with open('res_18/det_box.txt', mode='a+') as g:
                g.write(str(det[i + 1] - det[i]) + ' ' + str(det[i + 2] - det[i]) +
                        ' ' + str(det[i] * 2) + ' ' + str(det[i] * 2) + ' ' + str(det[i + 3]) + ' ' + '\n')
            # with open('res_18/det.txt', mode='a+') as g:
            #     g.write(str(det[i]) + ' ' + str(det[i + 1]) + ' ' + str(det[i + 2]) + ' ' + str(det[i + 3]) + ' ' + '\n')
        m += 1