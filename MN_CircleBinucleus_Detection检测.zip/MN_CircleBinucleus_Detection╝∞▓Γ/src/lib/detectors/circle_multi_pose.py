# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/21 12:57
@Auth ： wongbooming
@File ：circle_multi_pose.py
@Explain :
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import cv2
import numpy as np
from progress.bar import Bar
import time
import torch
import os

from nms_torch.nms import soft_nms as soft_nms_39
# from external.nms import soft_nms_39
from models.decode import circle_multi_pose_decode
from models.utils import flip_tensor, flip_lr_off, flip_lr
from utils.image import get_affine_transform
from utils.post_process import circle_multi_pose_post_process
from utils.debugger import Debugger

from .base_detector import BaseDetector


class CircleMultiPoseDetector(BaseDetector):
    def __init__(self, opt):
        super(CircleMultiPoseDetector, self).__init__(opt)
        # self.flip_idx = opt.flip_idx

    def process(self, images, return_time=False):
        with torch.no_grad():
            torch.cuda.synchronize()
            output = self.model(images)[-1]
            output['hm'] = output['hm'].sigmoid_()
            if self.opt.hm_hp and not self.opt.mse_loss:
                output['hm_hp'] = output['hm_hp'].sigmoid_()

            reg = output['reg'] if self.opt.reg_offset else None
            hm_hp = output['hm_hp'] if self.opt.hm_hp else None
            hp_offset = output['hp_offset'] if self.opt.reg_hp_offset else None
            torch.cuda.synchronize()
            forward_time = time.time()

            if self.opt.flip_test:
                output['hm'] = (output['hm'][0:1] + flip_tensor(output['hm'][1:2])) / 2
                # output['wh'] = (output['wh'][0:1] + flip_tensor(output['wh'][1:2])) / 2
                output['radius'] = (output['radius'][0:1] + flip_tensor(output['radius'][1:2])) / 2

                output['hps'] = (output['hps'][0:1] +
                                 flip_lr_off(output['hps'][1:2], self.flip_idx)) / 2
                hm_hp = (hm_hp[0:1] + flip_lr(hm_hp[1:2], self.flip_idx)) / 2 \
                    if hm_hp is not None else None
                reg = reg[0:1] if reg is not None else None
                hp_offset = hp_offset[0:1] if hp_offset is not None else None

            dets = circle_multi_pose_decode(
                output['hm'], output['radius'], output['hps'],
                reg=reg, hm_hp=hm_hp, hp_offset=hp_offset, K=self.opt.K)

        if return_time:
            return output, dets, forward_time
        else:
            return output, dets

    def post_process(self, dets, meta, scale=1):
        dets = dets.detach().cpu().numpy().reshape(1, -1, dets.shape[2])
        dets = circle_multi_pose_post_process(
            dets.copy(), [meta['c']], [meta['s']],
            meta['out_height'], meta['out_width'])
        for j in range(1, self.num_classes + 1):
            dets[0][j] = np.array(dets[0][j], dtype=np.float32).reshape(-1, 11)
            # import pdb; pdb.set_trace()
            dets[0][j][:, :3] /= scale
            dets[0][j][:, 4:] /= scale
        return dets[0]

    def merge_outputs(self, detections):
        results = {}
        results[1] = np.concatenate(
            [detection[1] for detection in detections], axis=0).astype(np.float32)
        if self.opt.nms or len(self.opt.test_scales) > 1:
            soft_nms_39(results[1], Nt=0.5, method=2)
        results[1] = results[1].tolist()
        return results

    def debug(self, debugger, images, dets, output, scale=1):
        dets = dets.detach().cpu().numpy().copy()
        dets[:, :, :3] *= self.opt.down_ratio
        dets[:, :, 4:10] *= self.opt.down_ratio
        img = images[0].detach().cpu().numpy().transpose(1, 2, 0)
        img = np.clip(((
                               img * self.std + self.mean) * 255.), 0, 255).astype(np.uint8)
        pred = debugger.gen_colormap(output['hm'][0].detach().cpu().numpy())
        debugger.add_blend_img(img, pred, 'pred_hm')
        if self.opt.hm_hp:
            pred = debugger.gen_colormap_hp(
                output['hm_hp'][0].detach().cpu().numpy())
            debugger.add_blend_img(img, pred, 'pred_hmhp')

    def show_results(self, debugger, image, results, image_name):
        debugger.add_img(image, img_id='circle_multi_pose')
        for circle in results[1]:
            # if circle[3] > self.opt.vis_thresh:
            if circle[3] > 0.2:
                debugger.add_coco_circle(circle[:3], circle[-1], circle[3], img_id='circle_multi_pose')
                debugger.add_coco_hp(circle[4:10], img_id='circle_multi_pose')
        # debugger.show_all_imgs(pause=self.pause)
        os.makedirs(self.opt.demo_dir, exist_ok=True)
        debugger.save_all_imgs(path=self.opt.demo_dir, prefix='', genID=False, name_id=image_name)