# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/21 20:37
@Auth ： wongbooming
@File ：sesese.py
@Explain :
"""

def circledet_decode(heat, cl, reg=None, cat_spec_wh=False, K=100):
    batch, cat, height, width = heat.size()

    # heat = torch.sigmoid(heat)
    # perform nms on heatmaps
    heat = _nms(heat)

    scores, inds, clses, ys, xs = _topk(heat, K=K)
    if reg is not None:
        reg = _tranpose_and_gather_feat(reg, inds)
        reg = reg.view(batch, K, 2)
        xs = xs.view(batch, K, 1) + reg[:, :, 0:1]
        ys = ys.view(batch, K, 1) + reg[:, :, 1:2]
    else:
        xs = xs.view(batch, K, 1) + 0.5
        ys = ys.view(batch, K, 1) + 0.5
    cl = _tranpose_and_gather_feat(cl, inds)

    cl = cl.view(batch, K, 1)
    clses = clses.view(batch, K, 1).float()
    scores = scores.view(batch, K, 1)
    # print(scores)
    circles = torch.cat([xs, ys, cl], dim=2)
    # bboxes = torch.cat([xs - wh[..., 0:1] / 2,
    #                     ys - wh[..., 1:2] / 2,
    #                     xs + wh[..., 0:1] / 2,
    #                     ys + wh[..., 1:2] / 2], dim=2)
    detections = torch.cat([circles, scores, clses], dim=2)
    return detections