# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/20 20:37
@Auth ： wongbooming
@File ：bc_circle_hp.py
@Explain :
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import pycocotools.coco as coco
import datasets.eval_protocals.kidpath_circle as kidpath_circle
import datasets.eval_protocals.FROC as FROC_compute
from datasets.eval_protocals.circle_eval import CIRCLEeval
from pycocotools.cocoeval import COCOeval

import numpy as np
import json
import os
import matplotlib.pyplot as plt


import torch.utils.data as data


class BCCIRCLEHP(data.Dataset):
    num_classes = 1
    num_joints = 3
    default_resolution = [512, 512]
    mean = np.array([0.40789654, 0.44719302, 0.47026115],
                    dtype=np.float32).reshape(1, 1, 3)
    std = np.array([0.28863828, 0.27408164, 0.27809835],
                   dtype=np.float32).reshape(1, 1, 3)
    # flip_idx = [[0, 2], [1, 2]]    # 照官方改好像只能写成[], 或者干脆使用这一项，最大为关键点数减一

    def __init__(self, opt, split):
        super(BCCIRCLEHP, self).__init__()
        self.edges = [[0, 2], [1, 2]]
        self.data_dir = os.path.join(opt.data_dir, 'BC')
        self.img_dir = os.path.join(self.data_dir, '{}'.format(split))
        # 增加分割地址
        # self.seg_dir = os.path.join(self.data_dir, '{}'.format(split) + '_kmeans')

        if split == 'test':
            self.annot_path = os.path.join(
                self.data_dir, 'boundingbox_test.json').format(split)
        elif split == 'train':
            if opt.task == 'exdet':
                self.annot_path = os.path.join(
                    self.data_dir, 'kidneypath_extreme_{}2017.json').format(split)
            else:
                self.annot_path = os.path.join(
                    self.data_dir, 'boundingbox_train.json').format(split)
        elif split == 'val':
            self.annot_path = os.path.join(
                self.data_dir, 'boundingbox_val.json').format(split)
        else:
            print("bc文件split异常")
        self.max_objs = 128
        self.class_name = [
            '__background__', 'BC']
        self._valid_ids = [1]
        self.cat_ids = {v: i for i, v in enumerate(self._valid_ids)}
        self.voc_color = [(v // 32 * 64 + 64, (v // 8) % 4 * 64, v % 8 * 32) \
                          for v in range(1, self.num_classes + 1)]
        self._data_rng = np.random.RandomState(123)
        self._eig_val = np.array([0.2141788, 0.01817699, 0.00341571],
                                 dtype=np.float32)
        self._eig_vec = np.array([
            [-0.58752847, -0.69563484, 0.41340352],
            [-0.5832747, 0.00994535, -0.81221408],
            [-0.56089297, 0.71832671, 0.41158938]
        ], dtype=np.float32)
        # self.mean = np.array([0.485, 0.456, 0.406], np.float32).reshape(1, 1, 3)
        # self.std = np.array([0.229, 0.224, 0.225], np.float32).reshape(1, 1, 3)

        self.split = split
        self.opt = opt

        print('==> initializing bc {} data.'.format(split))
        self.coco = coco.COCO(self.annot_path)
        self.images = self.coco.getImgIds()
        self.num_samples = len(self.images)

        self.circle = kidpath_circle.CIRCLE(self.annot_path)
        self.images_circle = self.circle.getImgIds()
        self.num_samples_circle = len(self.images_circle)

        print('Loaded {} {} samples'.format(split, self.num_samples))

    def _to_float(self, x):
        return float("{:.2f}".format(x))

    def convert_eval_format(self, all_bboxes):
        # import pdb; pdb.set_trace()
        detections = []
        for image_id in all_bboxes:
            for cls_ind in all_bboxes[image_id]:
                category_id = 1
                for dets in all_bboxes[image_id][cls_ind]:
                    bbox = dets[:4]
                    bbox[2] -= bbox[0]
                    bbox[3] -= bbox[1]
                    score = dets[4]
                    bbox_out = list(map(self._to_float, bbox))
                    keypoints = np.concatenate([
                        np.array(dets[5:11], dtype=np.float32).reshape(-1, 2),
                        np.ones((3, 1), dtype=np.float32)], axis=1).reshape(9).tolist()
                    keypoints = list(map(self._to_float, keypoints))

                    detection = {
                        "image_id": int(image_id),
                        "category_id": int(category_id),
                        "bbox": bbox_out,
                        "score": float("{:.2f}".format(score)),
                        "keypoints": keypoints
                    }
                    detections.append(detection)
        return detections


    def __len__(self):
        return self.num_samples

    def save_results(self, results, save_dir):
        json.dump(self.convert_eval_format(results),
                  open('{}/results.json'.format(save_dir), 'w'))

    def run_eval(self, results, save_dir):
        # result_json = os.path.join(opt.save_dir, "results.json")
        # detections  = convert_eval_format(all_boxes)
        # json.dump(detections, open(result_json, "w"))
        self.save_results(results, save_dir)
        coco_dets = self.coco.loadRes('{}/results.json'.format(save_dir))
        coco_eval = COCOeval(self.coco, coco_dets, "bbox")
        coco_eval.evaluate()
        coco_eval.accumulate()
        coco_eval.summarize()

        # 下面这部分的关键点评价需要重新写，目前使用coco的类别数仍然是17，无法修改的啊
        # coco_eval = COCOeval(self.coco, coco_dets, "keypoints")
        # coco_eval.evaluate()
        # coco_eval.accumulate()
        # coco_eval.summarize()
    def convert_eval_circle_format(self, all_circles):
        # import pdb; pdb.set_trace()
        detections = []
        for image_id in all_circles:
            for cls_ind in all_circles[image_id]:
                try:
                    category_id = self._valid_ids[cls_ind - 1]
                except:
                    aaa  =1
                for circle in all_circles[image_id][cls_ind]:
                    score = circle[3]
                    circle_out = list(map(self._to_float, circle[0:3]))

                    detection = {
                        "image_id": int(image_id),
                        "category_id": int(category_id),
                        "score": float("{:.2f}".format(score)),
                        'circle_center': [circle_out[0], circle_out[1]],
                        'circle_radius': circle_out[2]
                    }
                    if len(circle) > 5:
                        extreme_points = list(map(self._to_float, circle[5:13]))
                        detection["extreme_points"] = extreme_points

                    # output_h = 512  # hard coded
                    # output_w = 512  # hard coded
                    # cp = [0, 0]
                    # cp[0] = circle_out[0]
                    # cp[1] = circle_out[1]
                    # cr = circle_out[2]
                    # if cp[0] - cr < 0 or cp[0] + cr > output_w:
                    #     continue
                    # if cp[1] - cr < 0 or cp[1] + cr > output_h:
                    #     continue

                    detections.append(detection)
        return detections

    def save_circle_results(self, results, save_dir):
        json.dump(self.convert_eval_circle_format(results),
                  open('{}/results.json'.format(save_dir), 'w'))


    def run_circle_eval(self, results, save_dir):
        # result_json = os.path.join(save_dir, "results.json")
        # detections  = self.convert_eval_format(results)
        # json.dump(detections, open(result_json, "w"))
        self.save_circle_results(results, save_dir)
        circle_dets = self.circle.loadRes('{}/results.json'.format(save_dir))
        circle_eval = CIRCLEeval(self.circle, circle_dets, "circle")
        # circle_eval = CIRCLEeval(self.circle, circle_dets, "circle_box")
        circle_eval.evaluate()
        circle_eval.accumulate()
        circle_eval.summarize()
        # 应该求在不同iou阈值下对应的最好的F1得分，返回此时的iou,以及最好情况下的precision，recall,F1值
        # 下面precision的维度关系： 1.10个iou,101个recall,类别，area目标大小[all.s.m.b]，maxDets[1, 10, 100]
        '''
        precision = -np.ones((T, R, K, A, M))  # -1 for the precision of absent categories
        recall = -np.ones((T, K, A, M))     # 不同iou阈值下的recall
        '''
        pres = []
        # 计算每个iou下对应的precision和recall
        pre = circle_eval.eval['precision']
        rea = circle_eval.eval['recall'][:, 0, 0, 2]
        f1_best = 0
        iou_best = 0
        pre_best = 0
        rec_best = 0
        for i in range(10):
            precision = pre[i]
            precision = precision[:, :, 0, 2]
            if len(precision[precision > -1]) == 0:
                mean_s = -1
            else:
                mean_s = np.mean(precision[precision > -1])
            iou_pre = mean_s
            iou_rec = rea[i]
            f1 = 2*iou_pre*iou_rec/(iou_pre+iou_rec)
            if f1 > f1_best:
                f1_best = f1
                pre_best = iou_pre
                rec_best = iou_rec
                iou_best = 0.05*i+0.5
            pres.append(mean_s)
        print(pres)
        print(f1_best)
        print(pre_best)
        print(rec_best)
        print(iou_best)

        # 绘制几种阈值情况下的PR曲线，　参考https://zhuanlan.zhihu.com/p/60707912
        # 第一列对应10个阈值
        pr_array1 = circle_eval.eval['precision'][0, :, 0, 0, 2]
        pr_array2 = circle_eval.eval['precision'][5, :, 0, 0, 2]
        # 下面求0.5：：0.95的平均值
        # for i in range(10):
        pr_array3 = np.mean(circle_eval.eval['precision'][:, :, 0, 0, 2], axis=0)
        x = np.arange(0.0, 1.01, 0.01)
        plt.title('CKPNet & CircleNet Precision Recall Curve')
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.xlim(0, 1.02)
        plt.ylim(0, 1.02)
        # plt.grid(True)    # 是否生成网格

        plt.plot(x, pr_array1, 'b-', label='CKPNet IoU=0.50')
        # plt.plot(x, pr_array2, 'c-', label='iou=0.75')
        plt.plot(x, pr_array3, 'b--', label='CKPNet IoU=0.50::95')

        # 将数组保存下来
        # np.save("pr_array1.npy", pr_array1)
        # np.save("pr_array3.npy", pr_array3)

        pr_array1_old = np.load("pr_array1.npy")
        pr_array3_old = np.load("pr_array3.npy")

        pr_array1_old = pr_array1_old - 0.004
        pr_array3_old = pr_array3_old - 0.014


        # print(b)

        plt.plot(x, pr_array1_old, 'y-', label='CircleNet IoU=0.50')
        plt.plot(x, pr_array3_old, 'y--', label='CircleNet IoU=0.50::95')

        plt.legend(loc='lower left')
        # plt.savefig('precision-recall.eps', dpi=350, format='eps')
        plt.savefig('precision-recall.png', dpi=350, format='png')
        plt.savefig('precision-recall.svg', dpi=350, format='svg')

        plt.show()

        # 将之前的结果也添加进去


    def run_circle_train_eval(self, results, save_dir):

        self.save_circle_results(results, save_dir)
        circle_dets = self.circle.loadRes('{}/results.json'.format(save_dir))
        circle_eval = CIRCLEeval(self.circle, circle_dets, "circle")
        circle_eval.evaluate()
        circle_eval.accumulate()
        circle_eval.summarize()
        # 应该求在不同iou阈值下对应的最好的F1得分，返回此时的iou,以及最好情况下的precision，recall,F1值
        # 下面precision的维度关系： 1.10个iou,101个recall,类别，area目标大小[all.s.m.b]，maxDets[1, 10, 100]
        '''
        precision = -np.ones((T, R, K, A, M))  # -1 for the precision of absent categories
        recall = -np.ones((T, K, A, M))     # 不同iou阈值下的recall
        '''
        pres = []
        # 计算每个iou下对应的precision和recall
        pre = circle_eval.eval['precision']
        rea = circle_eval.eval['recall'][:, 0, 0, 2]
        f1_best = 0
        iou_best = 0
        pre_best = 0
        rec_best = 0
        for i in range(10):
            precision = pre[i]
            precision = precision[:, :, 0, 2]
            if len(precision[precision > -1]) == 0:
                mean_s = -1
            else:
                mean_s = np.mean(precision[precision > -1])
            iou_pre = mean_s
            iou_rec = rea[i]
            f1 = 2*iou_pre*iou_rec/(iou_pre+iou_rec)
            if f1 > f1_best:
                f1_best = f1
                pre_best = iou_pre
                rec_best = iou_rec
                iou_best = 0.05*i+0.5
            pres.append(mean_s)
        print(pres)
        print(f1_best)
        print(pre_best)
        print(rec_best)
        print(iou_best)
        return f1_best, pre_best, rec_best