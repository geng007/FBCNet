# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/17 21:29
@Auth ： wongbooming
@File ：对剔除出来的异常进行二次处理，提取图像到文件夹下.py
@Explain :
"""
import os, shutil

images_path = r'E:\MN_datasheet\Data_BC\keypoints'
new_images_path = r'E:\MN_datasheet\Data_BC\images_new'
key_path = r'E:\MN_datasheet\Data_BC\keypoints_new'
os.makedirs(new_images_path, exist_ok=True)

names = os.listdir(new_images_path)
for name in names:
    name = name.replace('.jpg', '.txt')
    shutil.copy(images_path + '\\' + name, key_path + '\\' + name)

# images_path = r'E:\MN_datasheet\Data_BC\images'
# new_images_path = r'E:\MN_datasheet\Data_BC\images_new'
# os.makedirs(new_images_path, exist_ok=True)
#
# with open('异常.txt', 'r') as f:
#     for key_line in f.readlines():
#         key_line = key_line.replace('\n', '')
#         shutil.copy(images_path + '\\' + key_line, new_images_path + '\\' + key_line)