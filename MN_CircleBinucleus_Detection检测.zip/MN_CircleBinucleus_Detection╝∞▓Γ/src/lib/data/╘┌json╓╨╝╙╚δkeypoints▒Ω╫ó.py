# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/17 20:18
@Auth ： wongbooming
@File ：在json中加入keypoints标注.py
@Explain :
"""

# -*- coding: UTF-8 -*-
import cv2
import json
import sys, math


# process bar
def process_bar(count, total, status=''):
    bar_len = 60
    filled_len = int(round(bar_len * count / float(total)))
    percents = round(100.0 * count / float(total), 1)
    bar = '=' * filled_len + '-' * (bar_len - filled_len)
    sys.stdout.write('[%s] %s%s ...%s\r' % (bar, percents, '%', status))
    sys.stdout.flush()


def txt2coco(txt_path="label_train.txt", json_path="train.json", image_path="./BC/images/", keypoints_ann_path='.'):
    root_path = image_path  # 图像的存储路径
    images, categories, annotations = [], [], []
    category_dict = {"BC": 1}
    for cat_n in category_dict:
        categories.append({"supercategory": "", "id": category_dict[cat_n], "name": cat_n})
    with open(txt_path, 'r') as f:
        img_id = 0
        anno_id_count = 0
        count = 1
        total = 12
        for line in f.readlines():
            process_bar(count, total)
            count += 1
            line = line.split(' ')
            img_name = line[0]
            bbox_num = int(line[1])
            img_cv2 = cv2.imread(root_path + img_name)
            [height, width, _] = img_cv2.shape

            # images info
            images.append({"file_name": img_name, "height": height, "width": width, "id": img_id})

            for i in range(0, bbox_num):
                category_id = int(line[i * 5 + 2])
                x1 = float(line[i * 5 + 3])
                y1 = float(line[i * 5 + 4])
                x2 = float(line[i * 5 + 3]) + float(line[i * 5 + 5])
                y2 = float(line[i * 5 + 4]) + float(line[i * 5 + 6])
                width = float(line[i * 5 + 5])
                height = float(line[i * 5 + 6])

                bbox = [x1, y1, width, height]      # 左上角的坐标及宽高， 坐标的方式是在第四象限，且x越往右越大，y越往下越大
                segment = [x1, y1, x2, y1, x2, y2, x1, y2]
                area = width * height
                circle_center = [float(x1 + 0.5 * width), float(y1 + 0.5 * height)]
                circle_radius = min(float(0.5 * width), float(0.5 * height))

                # 插入keypoints信息，首先思路是打开txt文件
                keypoints = []
                with open(keypoints_ann_path + '\\' + img_name.replace('.jpg', '.txt'), 'r') as k:
                    for key_line in k.readlines():
                        print(key_line)
                        if key_line[1] == ' ':
                            pass
                        elif len(keypoints) == 6:   # 有两个关键点了，长度也就是6
                            break
                        elif float(key_line[0]) <= 1:
                            if len(key_line.split(' ')) == 2:
                                key_x = float(key_line.split(' ')[0])*512
                                key_y = float(key_line.split(' ')[1])*512
                                # 判断是否在当前的box内
                                # 到圆心的距离的平方：
                                dis_key_center= (key_x - circle_center[0])**2 + (key_y - circle_center[1])**2
                                if dis_key_center < circle_radius**2:
                                    print('*******************************')
                                    keypoints.append(key_x)
                                    keypoints.append(key_y)
                                    keypoints.append(2)     # 2表示此点有标注
                            else:
                                print('异常极值点只标了一个啊，那只能补上相同的' + img_name)
                                with open('异常.txt', 'a+') as y:
                                    y.write(img_name + '\n')
                                key_x = float(key_line.split(' ')[0]) * 512
                                key_y = key_x
                                # 判断是否在当前的box内
                                # 到圆心的距离的平方：
                                dis_key_center = (key_x - circle_center[0]) ** 2 + (key_y - circle_center[1]) ** 2
                                if dis_key_center < circle_radius ** 2:
                                    keypoints.append(key_x)
                                    keypoints.append(key_y)
                                    keypoints.append(2)

                if len(keypoints) != 6:
                    if len(keypoints) == 0:
                        print('异常 空的 说明漏标了关键点' + img_name)
                        with open('异常.txt', 'a+') as y:
                            y.write(img_name + '\n')
                        keypoints = [float(x1 + 0.5 * width), float(y1 + 0.5 * height), 2,
                                     float(x1 + 0.5 * width), float(y1 + 0.5 * height), 2]
                    else:
                        with open('异常.txt', 'a+') as y:
                            y.write(img_name + '\n')
                        print('异常不到6各' + str(len(keypoints)) + img_name)
                        keypoints = [float(x1 + 0.5 * width), float(y1 + 0.5 * height), 2,
                                     float(x1 + 0.5 * width), float(y1 + 0.5 * height), 2]

                # 把圆心坐标也加入关键点，变成三个关键点
                keypoints.append(circle_center[0])
                keypoints.append(circle_center[1])
                keypoints.append(2)

                # 对关键点的顺序进行排序：距离圆心较近的关键点在第一个
                k_1_x = keypoints[0]
                k_1_y = keypoints[1]
                k_2_x = keypoints[3]
                k_2_y = keypoints[4]
                k_3_x = keypoints[6]
                k_3_y = keypoints[7]
                if (math.pow((k_1_x - k_3_x), 2) + math.pow((k_1_y - k_3_y), 2)) > \
                    (math.pow((k_2_x - k_3_x), 2) + math.pow((k_2_y - k_3_y), 2)):
                    keypoints[0], keypoints[1], keypoints[3], keypoints[4] = \
                        keypoints[3], keypoints[4], keypoints[0], keypoints[1]
                else:
                    pass

                if len(keypoints) != 9:
                    print('异常，根本没有加入圆心坐标形成关键点_' + img_name)
                else:
                    pass

                anno_info = {'id': anno_id_count, 'category_id': category_id, 'bbox': bbox,
                             'num_keypoints': 3,    # 加入圆心后也要改为3
                             'keypoints': keypoints,
                             'circle_center': circle_center, 'circle_radius': circle_radius,
                             'segmentation': [segment],
                             'area': area, 'iscrowd': 0, 'image_id': img_id}
                annotations.append(anno_info)
                anno_id_count += 1

            img_id = img_id + 1

    all_json = {"images": images, "annotations": annotations, "categories": categories}

    with open(json_path, "w") as outfile:
        json.dump(all_json, outfile)


if __name__ == "__main__":
    txt2coco(txt_path="./BC/label_train.txt", json_path="BC/boundingbox_train_new.json",
             image_path="BC/train/", keypoints_ann_path=r'E:\MN_datasheet\Data_BC\keypoints')
    # txt2coco(txt_path="./MNData/coco/label_val.txt", json_path="./MNData/coco/annotations/boundingbox_val.json",
    #          image_path="./MNData/coco/images/val/")
