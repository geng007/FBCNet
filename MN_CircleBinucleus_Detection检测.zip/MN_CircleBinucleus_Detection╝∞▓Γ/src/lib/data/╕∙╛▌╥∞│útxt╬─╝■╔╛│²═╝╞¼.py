# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/20 18:27
@Auth ： wongbooming
@File ：根据异常txt文件删除图片.py
@Explain :
"""

import os, shutil

# 异常txt文件的地址
txt_path = r'原始异常.txt'
# 待删除的image目录总地址为
image_path = r'BC'

# 首先将异常的文件名读取出来
deleate_names = []
with open('原始异常.txt', 'r') as y:
    for line in y.readlines():
        deleate_names.append(line.replace('\n', ''))

for name in deleate_names:
    if os.path.exists(os.path.join(image_path + '\\test', name)):
        os.remove(os.path.join(image_path + '\\test', name))
    if os.path.exists(os.path.join(image_path + '\\train', name)):
        os.remove(os.path.join(image_path + '\\train', name))
    if os.path.exists(os.path.join(image_path + '\\val', name)):
        os.remove(os.path.join(image_path + '\\val', name))