# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/20 18:27
@Auth ： wongbooming
@File ：根据异常txt文件删除对应的label ttx文件.py
@Explain :
"""

import os, shutil

# 异常txt文件的地址
txt_path = r'原始异常.txt'
# 待删除的image目录总地址为
image_path = r'BC'

# 首先将异常的文件名读取出来
deleate_names = []
with open('原始异常.txt', 'r') as y:
    for line in y.readlines():
        deleate_names.append(line.replace('\n', ''))

# with open('BC/label_test.txt', 'r') as t:
#     for line in t.readlines():
#         if line.split(' ')[0] not in deleate_names:
#             with open('BC/label_test_new.txt', 'a+') as tn:
#                 tn.write(line)

with open('BC/label_train.txt', 'r') as t:
    for line in t.readlines():
        if line.split(' ')[0] not in deleate_names:
            with open('BC/label_train_new.txt', 'a+') as tn:
                tn.write(line)

with open('BC/label_val.txt', 'r') as t:
    for line in t.readlines():
        if line.split(' ')[0] not in deleate_names:
            with open('BC/label_val_new.txt', 'a+') as tn:
                tn.write(line)