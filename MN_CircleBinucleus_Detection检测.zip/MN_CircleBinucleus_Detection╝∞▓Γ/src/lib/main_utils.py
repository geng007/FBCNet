# -*- coding: utf-8 -*-
"""
@Time ： 2021/12/16 20:44
@Auth ： wongbooming
@File ：main_utils.py
@Explain :
"""
import numpy as np
import math
import fractions



def correct_rotate(preds2, height, weith, rotate_degree):
    for pred in preds2:
        bboxs = preds2[pred][1]
        for bi in range(len(bboxs)):
            if rotate_degree == 90:
                x1_new = bboxs[bi][1]
                y1_new = weith - bboxs[bi][2]
                x2_new = bboxs[bi][3]
                y2_new = weith - bboxs[bi][0]
                score = bboxs[bi][4]
                bboxs[bi] = [x1_new, y1_new, x2_new, y2_new, score]
        preds2[pred][1] = bboxs

    return preds2


def correct_rotate_circle(preds2, height, weith, rotate_degree):
    for pred in preds2:
        bboxs = preds2[pred][1]
        for bi in range(len(bboxs)):
            if rotate_degree == 90:
                x1_new = bboxs[bi][1]
                y1_new = weith - bboxs[bi][0]
                radius = bboxs[bi][2]
                score = bboxs[bi][3]
                zeroval = bboxs[bi][4]
                bboxs[bi] = [x1_new, y1_new, radius, score, zeroval]
        preds2[pred][1] = bboxs

    return preds2


def caculate_matching_rate_circle(preds, preds2, thres):
    all_box = 0
    match_box = 0
    for pred in preds:
        pred_bboxs = preds[pred][1]
        pred2_bboxs = preds2[pred][1]
        for bi in range(len(pred_bboxs)):
            if pred_bboxs[bi][3] >= thres:
                all_box = all_box + 1
            else:
                continue
            done_box = 0
            for bj in range(len(pred2_bboxs)):
                if pred2_bboxs[bj][3] < thres or done_box == 1:
                    continue
                overlap = circleIOU([pred2_bboxs[bj]], [pred_bboxs[bi]])
                if overlap > 0.5:
                    match_box = match_box + 1
                    done_box = 1
    return all_box, match_box


def circleIOU(d, g):
    ious = np.zeros((len(d), len(g)))
    for di in range(len(d)):
        center_d_x = d[di][0]
        center_d_y = d[di][1]
        center_d_r = d[di][2]
        for gi in range(len(g)):
            center_g_x = g[gi][0]
            center_g_y = g[gi][1]
            center_g_r = g[gi][2]
            distance = math.sqrt((center_d_x - center_g_x) ** 2 + (center_d_y - center_g_y) ** 2)
            if center_d_r <= 0 or center_g_r <= 0 or distance > (center_d_r + center_g_r):
                ious[di, gi] = 0
            else:
                overlap = solve(center_d_r, center_g_r, distance ** 2)
                union = math.pi * (center_d_r ** 2) + math.pi * (center_g_r ** 2) - overlap
                if union == 0:
                    ious[di, gi] = 0
                else:
                    ious[di, gi] = overlap / union
    return ious


def caculate_matching_rate(preds, preds2, thres):
    all_box = 0
    match_box = 0
    for pred in preds:
        pred_bboxs = preds[pred][1]
        pred2_bboxs = preds2[pred][1]
        for bi in range(len(pred_bboxs)):
            if pred_bboxs[bi][4] >= thres:
                all_box = all_box + 1
            else:
                continue
            done_box = 0
            for bj in range(len(pred2_bboxs)):
                if pred2_bboxs[bj][4] < thres or done_box == 1:
                    continue
                overlap = IOU(pred2_bboxs[bj], pred_bboxs[bi])
                if overlap > 0.5:
                    match_box = match_box + 1
                    done_box = 1
    return all_box, match_box


def solve(r1, r2, d_squared):
    r1, r2 = min(r1, r2), max(r1, r2)

    d = math.sqrt(d_squared)
    if d >= r1 + r2:  # circles are far apart
        return 0.0
    if r2 >= d + r1:  # whole circle is contained in the other
        return math.pi * r1 ** 2

    r1f, r2f, dsq = map(fractions.Fraction, [r1, r2, d_squared])
    r1sq, r2sq = map(lambda i: i * i, [r1f, r2f])
    numer1 = r1sq + dsq - r2sq
    cos_theta1_sq = numer1 * numer1 / (4 * r1sq * dsq)
    numer2 = r2sq + dsq - r1sq
    cos_theta2_sq = numer2 * numer2 / (4 * r2sq * dsq)
    theta1 = acos_sqrt(cos_theta1_sq, math.copysign(1, numer1))
    theta2 = acos_sqrt(cos_theta2_sq, math.copysign(1, numer2))
    result = r1 * r1 * f(theta1) + r2 * r2 * f(theta2)

    # pp("d = %.16e" % d)
    # pp("cos_theta1_sq = %.16e" % cos_theta1_sq)
    # pp("theta1 = %.16e" % theta1)
    # pp("theta2 = %.16e" % theta2)
    # pp("f(theta1) = %.16e" % f(theta1))
    # pp("f(theta2) = %.16e" % f(theta2))
    # pp("result = %.16e" % result)

    return result




def f(x):
    """
    Compute  x - sin(x) cos(x)  without loss of significance
    """
    if abs(x) < 0.01:
        return 2 * x ** 3 / 3 - 2 * x ** 5 / 15 + 4 * x ** 7 / 315
    return x - math.sin(x) * math.cos(x)


def acos_sqrt(x, sgn):
    """
    Compute acos(sgn * sqrt(x)) with accuracy even when |x| is close to 1.
    http://www.wolframalpha.com/input/?i=acos%28sqrt%281-y%29%29
    http://www.wolframalpha.com/input/?i=acos%28sqrt%28-1%2By%29%29
    """
    assert isinstance(x, fractions.Fraction)

    y = 1 - x
    if y < 0.01:
        # pp('y < 0.01')
        numers = [1, 1, 3, 5, 35]
        denoms = [1, 6, 40, 112, 1152]
        ans = fractions.Fraction('0')
        for i, (n, d) in enumerate(zip(numers, denoms)):
            ans += y ** i * n / d
        assert isinstance(y, fractions.Fraction)
        ans *= math.sqrt(y)
        if sgn >= 0:
            return ans
        else:
            return math.pi - ans

    return math.acos(sgn * math.sqrt(x))


def IOU(box1, gts):
    """compute intersection over union"""
    ixmin = np.maximum(gts[0], box1[0])
    iymin = np.maximum(gts[1], box1[1])
    ixmax = np.minimum(gts[2], box1[2])
    iymax = np.minimum(gts[3], box1[3])
    iw = np.maximum(ixmax - ixmin + 1., 0.)
    ih = np.maximum(iymax - iymin + 1., 0.)
    inters = iw * ih
    # union
    uni = ((box1[2] - box1[0] + 1.) * (box1[3] - box1[1] + 1.) +
           (gts[2] - gts[0] + 1.) *
           (gts[3] - gts[1] + 1.) - inters)
    overlaps = inters / uni
    # ovmax = np.max(overlaps)
    # jmax = np.argmax(overlaps)
    return overlaps
