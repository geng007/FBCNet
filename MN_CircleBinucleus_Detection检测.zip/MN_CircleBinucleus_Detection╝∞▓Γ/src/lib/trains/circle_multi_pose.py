# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/20 20:49
@Auth ： wongbooming
@File ：circle_multi_pose.py
@Explain :
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import numpy as np

from models.losses import FocalLoss, RegL1Loss, RegLoss, RegWeightedL1Loss
from models.decode import circle_multi_pose_decode
from models.utils import _sigmoid, flip_tensor, flip_lr_off, flip_lr
from utils.debugger import Debugger
from utils.post_process import multi_pose_post_process
from utils.oracle_utils import gen_oracle_map
from .base_trainer import BaseTrainer


class CircleMultiPoseLoss(torch.nn.Module):
    def __init__(self, opt):
        super(CircleMultiPoseLoss, self).__init__()
        self.crit = FocalLoss()
        self.crit_hm_hp = torch.nn.MSELoss() if opt.mse_loss else FocalLoss()
        self.crit_kp = RegWeightedL1Loss() if not opt.dense_hp else \
            torch.nn.L1Loss(reduction='sum')
        self.crit_reg = RegL1Loss() if opt.reg_loss == 'l1' else \
            RegLoss() if opt.reg_loss == 'sl1' else None
        self.opt = opt

    def forward(self, outputs, batch):
        opt = self.opt
        # hm_loss, wh_loss, off_loss = 0, 0, 0
        hm_loss, circle_radius_loss, off_loss = 0, 0, 0     # 大的目标圆形框的损失
        hp_loss, hm_hp_loss, hp_offset_loss = 0, 0, 0   # 关键点的损失
        for s in range(opt.num_stacks):
            output = outputs[s]
            output['hm'] = _sigmoid(output['hm'])   # [1, 1, 128, 128]
            if opt.hm_hp and not opt.mse_loss:
                output['hm_hp'] = _sigmoid(output['hm_hp'])     # [1, 3, 128, 128]

            if opt.eval_oracle_hmhp:    # false
                output['hm_hp'] = batch['hm_hp']
            if opt.eval_oracle_hm:  # false
                output['hm'] = batch['hm']
            if opt.eval_oracle_kps:     # false
                if opt.dense_hp:
                    output['hps'] = batch['dense_hps']
                else:
                    output['hps'] = torch.from_numpy(gen_oracle_map(
                        batch['hps'].detach().cpu().numpy(),
                        batch['ind'].detach().cpu().numpy(),
                        opt.output_res, opt.output_res)).to(opt.device)
            if opt.eval_oracle_hp_offset:   # false 关键点回归？默认不开启，不开启也是有这个监督的，不知道这个是什么
                output['hp_offset'] = torch.from_numpy(gen_oracle_map(
                    batch['hp_offset'].detach().cpu().numpy(),
                    batch['hp_ind'].detach().cpu().numpy(),
                    opt.output_res, opt.output_res)).to(opt.device)

            hm_loss += self.crit(output['hm'], batch['hm']) / opt.num_stacks
            if opt.dense_hp:    # false
                mask_weight = batch['dense_hps_mask'].sum() + 1e-4
                hp_loss += (self.crit_kp(output['hps'] * batch['dense_hps_mask'],
                                         batch['dense_hps'] * batch['dense_hps_mask']) /
                            mask_weight) / opt.num_stacks
            else:   # output['hps']: [1, 6, 128, 128], batch['hps_mask']: [1, 128, 6], batch['ind']:[1, 128], batch['hps']: [1, 128, 6]
                '''
                # 关键点回归的损失函数， 由于关键点的标注本身不是很正确，因此将关键点回归的权重降低，增加另外一部分也就是关键点之间的距离比例
                三个关键点，前两个是核心，第三个是圆心，两个核心分别到圆心的距离相近程度约束，这种约束同时也可以解决三核四核问题
                其实这里的距离不是实际距离，是相对于矩形框中心的相对距离，也就是xy的偏移距离，但是不影响计算核心到圆心的相对距离
                src/lib/datasets/sample/circle_mutil_pose.py
                '''
                hp_loss += self.crit_kp(output['hps'], batch['hps_mask'],
                                        batch['ind'], batch['hps']) / opt.num_stacks
            if opt.wh_weight > 0:   # True: output['radius'][1, 1, 128, 128],batch['reg_mask'][1, 128],batch['radius'][1, 128, 1]
                circle_radius_loss += self.crit_reg(output['radius'], batch['reg_mask'],    # batch['ind']通过一维序列在二维128*128中找位置的
                                         batch['ind'], batch['radius']) / opt.num_stacks
                # wh_loss += self.crit_reg(output['wh'], batch['reg_mask'],
                #                          batch['ind'], batch['wh']) / opt.num_stacks
            if opt.reg_offset and opt.off_weight > 0:   # output['reg'][1, 2, 128, 128],batch['reg_mask'][1, 128],batch['reg'][1, 128, 2]
                off_loss += self.crit_reg(output['reg'], batch['reg_mask'],     # 只在有目标的区域进行偏移量的回归
                                          batch['ind'], batch['reg']) / opt.num_stacks
            if opt.reg_hp_offset and opt.off_weight > 0:    # True output['hp_offset'][1, 2, 128, 128],batch['hp_mask'][1, 384],batch['hp_ind'][1, 384],batch['hp_offset'][1, 384, 2]
                hp_offset_loss += self.crit_reg(    # batch['hp_ind'] 384的原因是 3*128，一共3个关键点，每个关键点偏移向量，这个偏移其实是减去整数之后的小数点偏移
                    output['hp_offset'], batch['hp_mask'],  # mask代表此处含有目标
                    batch['hp_ind'], batch['hp_offset']) / opt.num_stacks
            if opt.hm_hp and opt.hm_hp_weight > 0:  # True output['hm_hp'][1, 3, 128, 128],batch['hm_hp'][1, 3, 128, 128]
                hm_hp_loss += self.crit_hm_hp(
                    output['hm_hp'], batch['hm_hp']) / opt.num_stacks   # 除了圆的半径外，其他的权重均为1，半径的为0.1
                '''
                这种关键点的heatmap方式相比直接回归位置坐标的方式本事就自带相互之间的拓扑关系，无需再加入关系的学习loss
                '''
            '''
            尝试增加iou损失:根据heatmap计算圆形iou,output['hm'], batch['hm'], reg_offset为
            由heatmap计算的中心坐标点，然后搭配半径计算iou,然后计算交并比损失
            坑太多了算了：：：：从heatmap回归坐标的argmax不可导
            其实已经有了heatmap就不需要iou了
            '''
            # if opt.iou_weight > 0:
            #     for b in range(batch['ind'].shape[0]):
            #         # 实际的中心点一维坐标，假设二维是（a, b)， 则一维是 a*128+b
            #         # 下面这个gt_ind是个列表，每个batch含有真正目标的坐标列表， tensor([ 9470, 10780,  6521], device='cuda:0')
            #         gt_ind = batch['ind'][b, np.where(batch['ind'][b, :].cpu() != 0)][0]   # [B, 128],加入实际含有三个目标，则前三个是目标点的一维序列序号
            #         # 针对每个目标进行计算
            #         gts = []
            #         for i in range(len(batch['ind'][b, np.where(batch['ind'][b, :].cpu() != 0)][0])):
            #             # gt的二维坐标为, 根据hm的中心点计算
            #             gt_x, gt_y = np.array(np.where(batch['hm'][b, 0, :, :].cpu() == 1.)).T[i]
            #             # gt 对应的半径
            #             gt_radius = batch['radius'][b, :, 0][i].item()
            #             gts.append(gt_x)
            #             gts.append(gt_y)
            #             gts.append(gt_radius)
            #
            #         # 计算真正的目标个数
            #         gts_num = len(gts) // 3
            #         # 去取预测结果
            #         preds = []
            #         for j in range(gts_num):
            #             pred_x, pred_y =

        loss = opt.hm_weight * hm_loss + opt.wh_weight * circle_radius_loss + \
               opt.off_weight * off_loss + opt.hp_weight * hp_loss + \
               opt.hm_hp_weight * hm_hp_loss + opt.off_weight * hp_offset_loss
        '''
        说明： 整体热图，半径， 中心点偏移；关键点， 关键点热图， 关键点偏移
        '''
        loss_stats = {'loss': loss, 'hm_loss': hm_loss, 'hp_loss': hp_loss,
                      'hm_hp_loss': hm_hp_loss, 'hp_offset_loss': hp_offset_loss,
                      'radius_loss': circle_radius_loss, 'off_loss': off_loss}
        return loss, loss_stats


class CircleMultiPoseTrainer(BaseTrainer):
    def __init__(self, opt, model, optimizer=None):
        super(CircleMultiPoseTrainer, self).__init__(opt, model, optimizer=optimizer)

    def _get_losses(self, opt):
        loss_states = ['loss', 'hm_loss', 'hp_loss', 'hm_hp_loss',
                       'hp_offset_loss', 'radius_loss', 'off_loss']
        loss = CircleMultiPoseLoss(opt)
        return loss_states, loss

    def debug(self, batch, output, iter_id):
        opt = self.opt
        reg = output['reg'] if opt.reg_offset else None
        hm_hp = output['hm_hp'] if opt.hm_hp else None
        hp_offset = output['hp_offset'] if opt.reg_hp_offset else None
        dets = circle_multi_pose_decode(
            output['hm'], output['radius'], output['hps'],
            reg=reg, hm_hp=hm_hp, hp_offset=hp_offset, K=opt.K)
        dets = dets.detach().cpu().numpy().reshape(1, -1, dets.shape[2])
        dets[:, :, :3] *= opt.input_res / opt.output_res
        # 预测的半径不需要再放缩，都是4倍，这也就是半径loss很大的原因啊
        # dets[:, :, :2] *= opt.input_res / opt.output_res
        dets[:, :, 4:10] *= opt.input_res / opt.output_res
        dets_gt = batch['meta']['gt_det'].numpy().reshape(1, -1, dets.shape[2])
        dets_gt[:, :, :3] *= opt.input_res / opt.output_res
        dets_gt[:, :, 4:10] *= opt.input_res / opt.output_res
        for i in range(1):
            debugger = Debugger(
                dataset=opt.dataset, ipynb=(opt.debug == 3), theme=opt.debugger_theme)
            img = batch['input'][i].detach().cpu().numpy().transpose(1, 2, 0)
            img = np.clip(((
                                   img * opt.std + opt.mean) * 255.), 0, 255).astype(np.uint8)
            pred = debugger.gen_colormap(output['hm'][i].detach().cpu().numpy())
            gt = debugger.gen_colormap(batch['hm'][i].detach().cpu().numpy())
            debugger.add_blend_img(img, pred, 'pred_hm')
            debugger.add_blend_img(img, gt, 'gt_hm')

            debugger.add_img(img, img_id='out_pred')
            for k in range(len(dets[i])):   # 一共有一百个供选择的，也就是整整图像内最多预测100个，加入都大于阈值
                if dets[i, k, 3] > opt.center_thresh:
                    debugger.add_coco_circle(dets[i, k, :3], dets[i, k, -1],
                                           dets[i, k, 3], img_id='out_pred')
                    debugger.add_coco_hp(dets[i, k, 4:10], img_id='out_pred')

            debugger.add_img(img, img_id='out_gt')
            for k in range(len(dets_gt[i])):
                if dets_gt[i, k, 3] > opt.center_thresh:
                    debugger.add_coco_circle(dets_gt[i, k, :3], dets_gt[i, k, -1],
                                           dets_gt[i, k, 3], img_id='out_gt')
                    debugger.add_coco_hp(dets_gt[i, k, 4:10], img_id='out_gt')

            if opt.hm_hp:
                pred = debugger.gen_colormap_hp(output['hm_hp'][i].detach().cpu().numpy())
                gt = debugger.gen_colormap_hp(batch['hm_hp'][i].detach().cpu().numpy())
                debugger.add_blend_img(img, pred, 'pred_hmhp')
                debugger.add_blend_img(img, gt, 'gt_hmhp')

            if opt.debug == 4:
                debugger.save_all_imgs(opt.debug_dir, prefix='{}'.format(iter_id))
            else:
                debugger.show_all_imgs(pause=True)

    def save_result(self, output, batch, results):
        reg = output['reg'] if self.opt.reg_offset else None
        hm_hp = output['hm_hp'] if self.opt.hm_hp else None
        hp_offset = output['hp_offset'] if self.opt.reg_hp_offset else None
        dets = circle_multi_pose_decode(
            output['hm'], output['radius'], output['hps'],
            reg=reg, hm_hp=hm_hp, hp_offset=hp_offset, K=self.opt.K)
        dets = dets.detach().cpu().numpy().reshape(1, -1, dets.shape[2])

        dets_out = multi_pose_post_process(
            dets.copy(), batch['meta']['c'].cpu().numpy(),
            batch['meta']['s'].cpu().numpy(),
            output['hm'].shape[2], output['hm'].shape[3])
        results[batch['meta']['img_id'].cpu().numpy()[0]] = dets_out[0]