from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths

import os
import cv2
import numpy as np
from progress.bar import Bar
import torch

from lib.opts import opts
from lib.logger import Logger
from lib.utils.utils import AverageMeter
from lib.datasets.dataset_factory import dataset_factory
from lib.detectors.detector_factory import detector_factory


class PrefetchDataset(torch.utils.data.Dataset):
    def __init__(self, opt, dataset, pre_process_func):
        self.images = dataset.images
        self.load_image_func = dataset.coco.loadImgs
        self.img_dir = dataset.img_dir
        # self.seg_dir = dataset.seg_dir

        self.pre_process_func = pre_process_func
        self.opt = opt

    def __getitem__(self, index):
        img_id = self.images[index]
        img_info = self.load_image_func(ids=[img_id])[0]
        img_path = os.path.join(self.img_dir, img_info['file_name'])
        image = cv2.imread(img_path)
        # seg_path = os.path.join(self.seg_dir, img_info['file_name'])
        #
        # # 增加一个维度
        # # 在这里直接进行和分割图的拼接即可
        # seg = cv2.imread(seg_path, 0)
        # seg = np.expand_dims(seg, axis=-1)
        # image = np.concatenate((image, seg), axis=-1)
        images, meta = {}, {}
        for scale in opt.test_scales:
            if opt.task == 'ddd':
                images[scale], meta[scale] = self.pre_process_func(
                    image, scale, img_info['calib'])
            else:
                images[scale], meta[scale] = self.pre_process_func(image, scale)
        return img_id, img_info['file_name'], {'images': images, 'image': image, 'meta': meta}

    def __len__(self):
        return len(self.images)


def prefetch_test(opt):
    os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpus_str
    Dataset = dataset_factory[opt.dataset]
    opt = opts().update_dataset_info_and_set_heads(opt, Dataset)
    print(opt)
    Logger(opt)
    Detector = detector_factory[opt.task]
    split = 'val'
    dataset = Dataset(opt, split)
    detector = Detector(opt)
    data_loader = torch.utils.data.DataLoader(
        PrefetchDataset(opt, dataset, detector.pre_process),
        batch_size=1, shuffle=False, num_workers=0, pin_memory=True)
    results = {}
    num_iters = len(dataset)
    bar = Bar('{}'.format(opt.exp_id), max=num_iters)
    time_stats = ['tot', 'load', 'pre', 'net', 'dec', 'post', 'merge']
    avg_time_stats = {t: AverageMeter() for t in time_stats}
    for ind, (img_id, img_name, pre_processed_images) in enumerate(data_loader):
        # 为了测试froc，因此减少总的数据长度，加快推理速度
        # if ind == 105:
        #     break
        # else:
        #     print('ind:', ind)
        #     pass

        # cv2.imwrite(gt_save_path + '//' + str(ind) + '.jpg', pre_processed_images['image'][0, :, :, :].numpy())
        img_name = img_name[0].split('.')[0]
        ret = detector.run(pre_processed_images, img_name)
        results[img_id.numpy().astype(np.int32)[0]] = ret['results']
        Bar.suffix = '[{0}/{1}]|Tot: {total:} |ETA: {eta:} '.format(
            ind, num_iters, total=bar.elapsed_td, eta=bar.eta_td)
        for t in avg_time_stats:
            avg_time_stats[t].update(ret[t])
            Bar.suffix = Bar.suffix + '|{} {tm.val:.3f}s ({tm.avg:.3f}s) '.format(
                t, tm=avg_time_stats[t])
        bar.next()
    bar.finish()
    if opt.task == 'circledet':
        dataset.run_circle_eval(results, opt.save_dir)
    elif opt.task == 'multi_pose':
        dataset.run_eval(results, opt.save_dir)
    elif opt.task == 'circle_multi_pose':
        dataset.run_circle_eval(results, opt.save_dir)
    else:
        print('既不是circlenet也不是多关键点，test文件')


if __name__ == '__main__':
    os.environ['TORCH_HOME'] = r'E:\projects_models\detect\MN_CircleBinucleus_Detection\src\weights'

    # gt_save_path = r'E:\trainingrecords\circlenet\gt\test_original_images'

    opt = opts().parse()
    prefetch_test(opt)
