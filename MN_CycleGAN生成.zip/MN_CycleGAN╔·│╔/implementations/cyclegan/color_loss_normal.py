
import numpy as np
import scipy.stats as st

import torch
from torch import nn
from torch.nn import functional as F
import math


def gauss_kernel(kernlen=21, nsig=3, channels=1):
    interval = (2 * nsig + 1.) / (kernlen)
    x = np.linspace(-nsig - interval / 2., nsig + interval / 2., kernlen + 1)
    kern1d = np.diff(st.norm.cdf(x))
    kernel_raw = np.sqrt(np.outer(kern1d, kern1d))
    kernel = kernel_raw / kernel_raw.sum()
    out_filter = np.array(kernel, dtype=np.float32)
    out_filter = out_filter.reshape((kernlen, kernlen, 1, 1))
    out_filter = np.repeat(out_filter, channels, axis=2)
    return out_filter


class Blur(nn.Module):
    def __init__(self, nc):
        super(Blur, self).__init__()
        self.nc = nc
        kernel = gauss_kernel(kernlen=21, nsig=3, channels=self.nc)
        kernel = torch.from_numpy(kernel).permute(2, 3, 0, 1)
        self.weight = nn.Parameter(data=kernel, requires_grad=False)

    def forward(self, x):
        if x.size(1) != self.nc:
            raise RuntimeError(
                "The channel of input [%d] does not match the preset channel [%d]" % (x.size(1), self.nc))
        x = F.conv2d(x, self.weight, stride=1, padding=10, groups=self.nc)
        return x


class ColorLoss(nn.Module):
    def __init__(self):
        super(ColorLoss, self).__init__()

    def forward(self, x1, x2):
        # return torch.sum(torch.pow((x1 - x2), 2)).div(2 * x1.size()[0])
        return torch.sum(torch.pow((x1 - x2), 2)).div(2 * x1.size()[0])

class HSVLoss(nn.Module):
    def __init__(self, h=0, s=1, v=0.7, eps=1e-7, threshold_h=0.03, threshold_sv=0.1):
        super(HSVLoss, self).__init__()
        self.hsv = [h, s, v]
        self.loss = nn.L1Loss(reduction='none')
        self.eps = eps

        # since Hue is a circle (where value 0 is equal to value 1 that are both "red"),
        # we need a threshold to prevent the gradient explod effect
        # the smaller the threshold, the optimal hue can to more close to target hue
        self.threshold_h = threshold_h
        # since Hue and (Value and Satur) are conflict when generated image' hue is not the target Hue,
        # we have to condition V to prevent it from interfering the Hue loss
        # the larger the threshold, the ealier to activate V loss
        self.threshold_sv = threshold_sv

    def get_hsv(self, img):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # hue = torch.Tensor.to(device)
        img = img * 0.5 + 0.5
        hue = torch.Tensor(img.shape[0], img.shape[2], img.shape[3]).to(img.device)
        # img = im * 0.5 + 0.5
        # hue = torch.Tensor(im.shape[0], im.shape[2], im.shape[3]).to(im.device)

        hue[img[:, 2] == img.max(1)[0]] = 4.0 + ((img[:, 0] - img[:, 1]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 2] == img.max(1)[0]]
        hue[img[:, 1] == img.max(1)[0]] = 2.0 + ((img[:, 2] - img[:, 0]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 1] == img.max(1)[0]]
        hue[img[:, 0] == img.max(1)[0]] = (0.0 + ((img[:, 1] - img[:, 2]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 0] == img.max(1)[0]]) % 6

        hue[img.min(1)[0] == img.max(1)[0]] = 0.0
        hue = hue / 6

        saturation = (img.max(1)[0] - img.min(1)[0]) / (img.max(1)[0] + self.eps)
        saturation[img.max(1)[0] == 0] = 0

        value = img.max(1)[0]
        return hue, saturation, value

    def forward(self, input, target):
        h, s, v = self.get_hsv(input)   # input [4, 3, 96, 96]

        target_h, target_s, target_v = self.get_hsv(target)

        # target_h = torch.Tensor(h.shape).fill_(self.hsv[0]).to(input.device).type_as(h), 什么操作
        # target_s = torch.Tensor(s.shape).fill_(self.hsv[1]).to(input.device).type_as(s)
        # target_v = torch.Tensor(v.shape).fill_(self.hsv[2]).to(input.device).type_as(v)

        loss_h = self.loss(h, target_h)
        loss_h[loss_h < self.threshold_h] = 0.0
        loss_h = loss_h.mean()

        if loss_h < self.threshold_h * 3:
            loss_h = torch.Tensor([0]).to(input.device)

        loss_s = self.loss(s, target_s).mean()
        if loss_h.item() > self.threshold_sv:
            loss_s = torch.Tensor([0]).to(input.device)

        loss_v = self.loss(v, target_v).mean()
        if loss_h.item() > self.threshold_sv:
            loss_v = torch.Tensor([0]).to(input.device)

        return loss_h + 4e-1 * loss_s + 4e-1 * loss_v

class HSVLoss_improve(nn.Module):
    def __init__(self, h=130, s=115, v=165, eps=1e-7, threshold_h=0.03, threshold_sv=0.1):
        super(HSVLoss_improve, self).__init__()
        self.hsv = [h, s, v]
        self.loss = nn.L1Loss(reduction='none')
        self.eps = eps

        # since Hue is a circle (where value 0 is equal to value 1 that are both "red"),
        # we need a threshold to prevent the gradient explod effect
        # the smaller the threshold, the optimal hue can to more close to target hue
        self.threshold_h = threshold_h
        # since Hue and (Value and Satur) are conflict when generated image' hue is not the target Hue,
        # we have to condition V to prevent it from interfering the Hue loss
        # the larger the threshold, the ealier to activate V loss
        self.threshold_sv = threshold_sv

    def get_hsv(self, img):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # hue = torch.Tensor.to(device)
        img = img * 125 + 125   # img: [4, 3, 96, 96]
        hue = torch.Tensor(img.shape[0], img.shape[2], img.shape[3]).to(img.device)
        # batch, RGB
        hue[img[:, 2] == img.max(1)[0]] = 240.0 + (60.0 * (img[:, 0] - img[:, 1]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 2] == img.max(1)[0]]
        hue[img[:, 1] == img.max(1)[0]] = 120.0 + (60.0 * (img[:, 2] - img[:, 0]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 1] == img.max(1)[0]]
        hue[img[:, 0] == img.max(1)[0]] = (0.0 + (60.0 * (img[:, 1] - img[:, 2]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 0] == img.max(1)[0]])

        hue[img.min(1)[0] == img.max(1)[0]] = 0.0   # hue.mean = 3.4310     , 63.0596, 258
        hue = hue / 2   # 0.1578

        saturation = (img.max(1)[0] - img.min(1)[0]) / (img.max(1)[0] + self.eps)
        saturation[img.max(1)[0] == 0] = 0

        value = img.max(1)[0]
        return hue, saturation*255, value

    def forward(self, input, target):
        h, s, v = self.get_hsv(input)   # input [4, 3, 96, 96], 30.5129, 184, 203

        target_h, target_s, target_v = self.get_hsv(target)     # 131.6584, 134.9714, 155.3979

        # target_h = torch.Tensor(h.shape).fill_(self.hsv[0]).to(input.device).type_as(h), 什么操作
        # target_s = torch.Tensor(s.shape).fill_(self.hsv[1]).to(input.device).type_as(s)
        # target_v = torch.Tensor(v.shape).fill_(self.hsv[2]).to(input.device).type_as(v)

        loss_h = self.loss(h, target_h)
        # loss_h[loss_h < self.threshold_h] = 0.0
        loss_h = loss_h.mean()  # tensor(42.4697, grad_fn=<MeanBackward0>)

        # if loss_h < self.threshold_h * 3:
        #     loss_h = torch.Tensor([0]).to(input.device)

        loss_s = self.loss(s, target_s).mean()  # tensor(69.4601, grad_fn=<MeanBackward0>)
        # if loss_h.item() > self.threshold_sv:
        #     loss_s = torch.Tensor([0]).to(input.device)

        loss_v = self.loss(v, target_v).mean()  # tensor(48.0239, grad_fn=<MeanBackward0>)
        # if loss_h.item() > self.threshold_sv:
        #     loss_v = torch.Tensor([0]).to(input.device)

        # return loss_h + 4e-1 * loss_s + 4e-1 * loss_v

        # v经过opencv验证，没有影像
        return loss_h + loss_s + loss_v


class HSV_Distance(nn.Module):
    def __init__(self, h=0, s=1, v=0.7, eps=1e-7, threshold_h=0.03, threshold_sv=0.1):
        super(HSV_Distance, self).__init__()
        self.hsv = [h, s, v]
        self.loss = nn.L1Loss(reduction='none')
        self.eps = eps
        # since Hue is a circle (where value 0 is equal to value 1 that are both "red"),
        # we need a threshold to prevent the gradient explod effect
        # the smaller the threshold, the optimal hue can to more close to target hue
        self.threshold_h = threshold_h
        # since Hue and (Value and Satur) are conflict when generated image' hue is not the target Hue,
        # we have to condition V to prevent it from interfering the Hue loss
        # the larger the threshold, the ealier to activate V loss
        self.threshold_sv = threshold_sv

    def get_hsv(self, img):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # hue = torch.Tensor.to(device)
        img = img * 0.5 + 0.5
        hue = torch.Tensor(img.shape[0], img.shape[2], img.shape[3]).to(img.device)
        # img = im * 0.5 + 0.5
        # hue = torch.Tensor(im.shape[0], im.shape[2], im.shape[3]).to(im.device)

        hue[img[:, 2] == img.max(1)[0]] = 4.0 + ((img[:, 0] - img[:, 1]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 2] == img.max(1)[0]]
        hue[img[:, 1] == img.max(1)[0]] = 2.0 + ((img[:, 2] - img[:, 0]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 1] == img.max(1)[0]]
        hue[img[:, 0] == img.max(1)[0]] = (0.0 + ((img[:, 1] - img[:, 2]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 0] == img.max(1)[0]]) % 6

        hue[img.min(1)[0] == img.max(1)[0]] = 0.0
        hue = hue / 6

        saturation = (img.max(1)[0] - img.min(1)[0]) / (img.max(1)[0] + self.eps)
        saturation[img.max(1)[0] == 0] = 0

        value = img.max(1)[0]
        return hue, saturation, value

    def forward(self, input, target):
        h, s, v = self.get_hsv(input)

        target_h, target_s, target_v = self.get_hsv(target)

        # target_h = torch.Tensor(h.shape).fill_(self.hsv[0]).to(input.device).type_as(h), 什么操作,可以求出真实图像的平均HSV大小
        # target_s = torch.Tensor(s.shape).fill_(self.hsv[1]).to(input.device).type_as(s)
        # target_v = torch.Tensor(v.shape).fill_(self.hsv[2]).to(input.device).type_as(v)

        R = 100
        angle = 30
        h = R * math.cos(angle / 180 * math.pi)
        r = R * math.sin(angle / 180 * math.pi)
        x1 = r * v * s * math.cos(h / 180 * math.pi)
        y1 = r * v * s * math.sin(h / 180 * math.pi)
        z1 = h * (1 - v)
        x2 = r * target_v * target_s * math.cos(target_h / 180 * math.pi)
        y2 = r * target_v * target_s * math.sin(target_h / 180 * math.pi)
        z2 = h * (1 - target_v)
        dx = x1 - x2
        dy = y1 - y2
        dz = z1 - z2
        return math.sqrt(dx * dx + dy * dy + dz * dz)



if __name__ == '__main__':
    cl = ColorLoss()

    # rgb example
    blur_rgb = Blur(3)
    img_rgb1 = torch.randn(4, 3, 40, 40)
    img_rgb2 = torch.randn(4, 3, 40, 40)
    blur_rgb1 = blur_rgb(img_rgb1)
    blur_rgb2 = blur_rgb(img_rgb2)
    print(cl(blur_rgb1, blur_rgb2))

    # gray example
    blur_gray = Blur(1)
    img_gray1 = torch.randn(4, 1, 40, 40)
    img_gray2 = torch.randn(4, 1, 40, 40)
    blur_gray1 = blur_gray(img_gray1)
    blur_gray2 = blur_gray(img_gray2)
    print(cl(blur_gray1, blur_gray2))
