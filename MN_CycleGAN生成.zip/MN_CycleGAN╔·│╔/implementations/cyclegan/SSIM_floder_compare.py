"""
@Time ： 2021/6/30 21:37
@Auth ： wangbooming
@File ：SSIM_floder_compare.py
@IDE ：PyCharm
"""
# cyclegan生成的图像质量评价,系列文件夹内的逐个比较，选出差距最大的PSNR
# MSE
import cv2
import os
from sklearn.metrics import mean_squared_error
from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio
import matplotlib.pyplot as plt

def main(i):
    global generate, original
    floder_classical_path = r'E:\MN_datasheet\new_data\MN_average_select_96'
    floder_generate_path = r'E:\MN_datasheet\new_data_cyclegan\MN_gan_generate_96_test_plot_SSIM' + "\\" + str(i)
    floder_original_path = r'E:\MN_datasheet\new_data_cyclegan\MN_gan' + "\\" + str(i)

    MSE_generate_mean, PSNR_generate_mean, ssim_generate_mean = [], [], []
    MSE_original_mean, PSNR_original_mean, ssim_original_mean = [], [], []



    for root, dirs, files in os.walk(floder_generate_path):
        for file in files:
            img_generate_path = os.path.join(root, file)
            # print(img_generate_path)
            img_generate = cv2.imread(img_generate_path)
            img_generate = cv2.cvtColor(img_generate, cv2.COLOR_RGB2GRAY)
            MSE_generate, PSNR_generate, ssim_generate = [], [], []
            for root_, dirs_, files_ in os.walk(floder_classical_path):
                for file_ in files_:
                    img_classical_path = os.path.join(root_, file_)
                    img_classical = cv2.imread(img_classical_path)
                    img_classical = cv2.cvtColor(img_classical, cv2.COLOR_RGB2GRAY)

                    MSE_generate.append(mean_squared_error(img_classical, img_generate))
                    PSNR_generate.append(peak_signal_noise_ratio(img_classical, img_generate))
                    ssim_generate.append(
                        structural_similarity(img_classical, img_generate, data_range=255))  # 对比的两张图size应该相同
            MSE_generate_mean.append(sum(MSE_generate) / (len(MSE_generate)))
            PSNR_generate_mean.append(sum(PSNR_generate) / (len(PSNR_generate)))
            ssim_generate_mean.append(sum(ssim_generate) / (len(ssim_generate)))

        generate = sum(PSNR_generate_mean) / (len(PSNR_generate_mean))
        generate_PSNR.append(sum(PSNR_generate_mean) / (len(PSNR_generate_mean)))
        # print(generate_PSNR)
    for root, dirs, files in os.walk(floder_original_path):
        for file in files:
            img_original_path = os.path.join(root, file)
            # print(img_original_path)
            img_original = cv2.imread(img_original_path)
            img_original = cv2.cvtColor(img_original, cv2.COLOR_RGB2GRAY)
            MSE_original, PSNR_original, ssim_original = [], [], []
            for root_, dirs_, files_ in os.walk(floder_classical_path):
                for file_ in files_:
                    img_classical_path = os.path.join(root_, file_)
                    img_classical = cv2.imread(img_classical_path)
                    img_classical = cv2.cvtColor(img_classical, cv2.COLOR_RGB2GRAY)

                    MSE_original.append(mean_squared_error(img_classical, img_original))
                    PSNR_original.append(peak_signal_noise_ratio(img_classical, img_original))
                    ssim_original.append(
                        structural_similarity(img_classical, img_original, data_range=255))  # 对比的两张图size应该相同
            MSE_original_mean.append(sum(MSE_original) / (len(MSE_original)))
            PSNR_original_mean.append(sum(PSNR_original) / (len(PSNR_original)))
            ssim_original_mean.append(sum(ssim_original) / (len(ssim_original)))

        original = sum(PSNR_original_mean) / (len(PSNR_original_mean))
        original_PSNR.append(sum(PSNR_original_mean) / (len(PSNR_original_mean)))
        # print(original_PSNR)
    print(f"{i}的差距为{generate - original}")
    result[str(i)] = str(generate - original)


if __name__ == '__main__':
    generate_PSNR = []
    original_PSNR = []
    result = {}
    for i in range(80):
        main(i)
    print("generate_PSNR:",generate_PSNR)
    print("original_PSNR",original_PSNR)
    print('result:',result)
    print(max(result, key=result.get))

# x = [i for i in range(32)]  # 横坐标
#
# # plt.plot(x, MSE_generate_mean)
# # plt.plot(x, MSE_original_mean)
# plt.plot(x, PSNR_generate_mean)  # 峰值信噪比，生成的图像更清晰
# plt.plot(x, PSNR_original_mean)
# # plt.plot(x, ssim_generate_mean)   # 结构相似度
# # plt.plot(x, ssim_original_mean)
# plt.savefig("PSNR.png")
# plt.show()