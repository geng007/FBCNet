"""
@Time ： 2021/6/1 9:50
@Auth ： wangbaomin
@File ：test_96_floder.py
@IDE ：PyCharm
"""
import shutil

from models import GeneratorResNet

import os

import torchvision
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid

from torch.utils.data import DataLoader
from torch.autograd import Variable

from models import *
from datasets_floder import *
from utils import *

import torch


def to_img(x):
    out = (x + 1) * 0.5
    out = out.clamp(0, 1)
    out = out.view(-1, 3, 100, 100)  # 大小取决于generate源代码中的大小<96*1.12
    return out

def main():
    z_dimension=100
    input_shape = (3,96,96)
    G_AB = GeneratorResNet(input_shape,10).cuda()
    # generate=torch.load("G_test.pkl") # 源程序
    G_AB.load_state_dict(torch.load(r"E:\trainingrecords\GAN\new20211228\NBUD2NBUD\BN2BN_new_batch=16_res=10\G_AB_1040.pth"))

    Tensor = torch.cuda.FloatTensor

    # Image transformations
    transforms_ = [
        transforms.Resize(int(96 * 1.12), Image.BICUBIC),   # 修改之后影像图像质量，大小不变
        # transforms.Resize(int(96 * 2), Image.BICUBIC),
        transforms.RandomCrop((100, 100)),
        # transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ]
    # 切分文件夹
    """Saves a generated sample from the test set"""
    filePath = r'E:\MN_datasheet\single_extract\NBUD_average_rid_96'
    i = 0
    j = 0
    batch = 8
    for root, dirs, files in os.walk(filePath):
        for file in files:
            if i < batch * (j + 1):
                os.makedirs("E:/NBUD_gan/" + str(j), exist_ok=True)
                shutil.copyfile(filePath + '\\' + file, "E:/NBUD_gan/" + str(j) + '/' + str(i) + '.jpg')
            else:
                j += 1
                os.makedirs("E:/NBUD_gan/" + str(j), exist_ok=True)
                shutil.copyfile(filePath + '\\' + file, "E:/NBUD_gan/" + str(j) + '/' + str(i) + '.jpg')
            i += 1
    for num_floder in range(j):
        val_dataloader = DataLoader(
            ImageDataset("E:/NBUD_gan", transforms_=transforms_, unaligned=True, floder=num_floder),
            batch_size=batch,
            shuffle=False,
            num_workers=1,
        )

        """Saves a generated sample from the test set"""
        imgs = next(iter(val_dataloader))
        G_AB.eval()
        real_A = Variable(imgs.type(Tensor))
        fake_B = G_AB(real_A)

        # Arange images along x-axis
        for i in range(fake_B.size(0)):
            os.makedirs("E:/NBUD_gan_generate_all/", exist_ok=True)
            torchvision.utils.save_image(to_img(fake_B[i, :, :, :]), "E:/NBUD_gan_generate_all/"
                                         + '/{}.jpg'.format(num_floder * batch + i))
            os.makedirs("E:/NBUD_gan_generate/" + str(num_floder), exist_ok=True)
            torchvision.utils.save_image(to_img(fake_B[i, :, :, :]), "E:/NBUD_gan_generate/" +
                                         str(num_floder) + '/{}.jpg'.format(num_floder*batch + i))
        real_A = make_grid(real_A, nrow=batch, normalize=True)
        fake_B = make_grid(fake_B, nrow=batch, normalize=True)
        # Arange images along y-axis
        image_grid = torch.cat((real_A, fake_B), 1)
        os.makedirs("E:/NBUD_gan_generate_grid", exist_ok=True)
        save_image(image_grid,"E:/NBUD_gan_generate_grid/%d.jpg" % num_floder)

    print("over")


if __name__ == '__main__':
    main()
