"""
@Time ： 2021/6/12 22:22
@Auth ： wangbooming
@File ：img_complex_resize.py
@IDE ：PyCharm
"""
# 小图片拼接
import os
import random

from PIL import Image
import cv2
import numpy as np

def main():

    all_path = list()

    dir_smalls = r"E:\MN_datasheet\image_blending_blur\smalls"
    background_path = r'E:\MN_datasheet\image_blending_blur\background\1_background.jpg'
    save_path = r'E:\MN_datasheet\image_blending_blur\complex'
    # root文件夹的路径  dirs 路径下的文件夹列表  files路径下的文件列表
    for root, dirs, files in os.walk(dir_smalls):
        for file in files:
            if "png" in file:  # 子串在母串里面不
                all_path.append(os.path.join(root, file))

    print(all_path)
    print("all_path数量：", len(all_path))

    small_lists = os.listdir(dir_smalls)

    all_path = all_path[:2]
    locs = [(100, 50), (300, 200)]

    sizes_list = []
    background = Image.open(background_path, mode='r')
    for num in range(len(all_path)):
        # background = Image.open(background_path, mode='r')

        pic_fole_head = Image.open(dir_smalls + "\\" + small_lists[num])
        size = pic_fole_head.size
        sizes_list.append(size)

        loc = locs[num]
        print(loc)

        background.paste(pic_fole_head, loc)
    background.save(save_path + "\\" + "complex" + ".jpg")
    print(sizes_list)
    print(locs)

    img = cv2.imread(save_path + "complex" + ".jpg", 1)
    for loc in locs:
        per_image_Rmean = np.mean(img[(loc[0] - 10):(loc[1] - 10), (loc[0] + 10):(loc[1] + 10), 0])
        per_image_Gmean = np.mean(img[:, :, 1])
        per_image_Bmean = np.mean(img[:, :, 2])


if __name__ == '__main__':
    main()