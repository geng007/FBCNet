"""
@Time ： 2021/6/12 16:01
@Auth ： wangbooming
@File ：angle_rect.py
@IDE ：PyCharm
"""
import cv2
import numpy as np
from PIL import Image
import random
import os

'''
计算矩形偏移角度，并根据角度resize图像
'''

# name = 487
path = r"E:\rect_angle_test"
for root, dirs, files in os.walk(path):
    for file in files:
        name = file[:-4]
        print(name)
        imagepath = r"E:\rect_angle_test" + "\\" + str(name) + ".jpg"
        img = cv2.imread(imagepath, 1)
        # 把图片转换为灰度模式
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 中值滤波
        blur = cv2.medianBlur(gray, 3)  # 模板大小3*3
        # 二值化
        t, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # 黑白颠倒，不然计算轮廓面积好像有问题
        t, otsu_true = cv2.threshold(otsu, 0, 255, cv2.THRESH_BINARY_INV)
        cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'after_seg.png', otsu_true)
        # 闭运算空洞填充
        otsu_true = cv2.morphologyEx(otsu_true, cv2.MORPH_CLOSE, (3, 3), iterations=2)
        contours, _ = cv2.findContours(otsu_true, 2, 2)
        # print(len(contours))
        area = 0
        count_contours = len(contours)
        area_min = []
        for i in range(count_contours):
            # print("contours[" + str(i) + "]的面积=", cv2.contourArea(contours[i]))
            area = cv2.contourArea(contours[i]) + area
        # print("总面积为：%d" % area)
        for i in range(count_contours):
            if cv2.contourArea(contours[i]) < (area / 3):
                area_min.append(contours[i])
        cv2.drawContours(otsu_true, area_min, -1, (0, 255, 0), thickness=-1)
        cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'after_seg_remove&close.png', otsu_true)

        contours, _ = cv2.findContours(otsu_true, 2, 2)
        count_contours = len(contours)
        # print(len(contours))
        img = cv2.imread(imagepath, 1)
        if count_contours == 1:
            cnt = contours[0]
            rect = cv2.minAreaRect(cnt)
            box = cv2.boxPoints(rect)  # 获取最小外接矩形的4个顶点
            box = np.int0(box)
            print(box.ravel())
            # print(box)
            # 绘制最小外界矩
            for i in range(4):
                cv2.line(img, tuple(box[i]), tuple(box[(i + 1) % 4]), (0, 255, 255))  # 5
            # 旋转角度
            print(cv2.minAreaRect(cnt))
            theta = cv2.minAreaRect(cnt)[2]
            print(theta)
            im = Image.open(imagepath)
            # 横
            if 0 < theta < 22.5:
                width = random.randrange(86, 96)
                height = random.randrange(76, 86)
                out = im.resize((width, height), Image.ANTIALIAS)
                captcha = out.convert('RGB')
                # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
            elif 90 > theta > 67.5:  # 竖
                height = random.randrange(86, 96)
                width = random.randrange(76, 86)
                out = im.resize((width, height), Image.ANTIALIAS)
                captcha = out.convert('RGB')
                # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
            elif int(theta) == 90 or abs(int(theta)) == 0:
                if cv2.minAreaRect(cnt)[1][0] > cv2.minAreaRect(cnt)[1][1]:
                    height = random.randrange(86, 96)
                    width = random.randrange(76, 86)
                    out = im.resize((width, height), Image.ANTIALIAS)
                    captcha = out.convert('RGB')
                    # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                    captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
                else:
                    width = random.randrange(86, 96)
                    height = random.randrange(76, 86)
                    out = im.resize((width, height), Image.ANTIALIAS)
                    captcha = out.convert('RGB')
                    # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                    captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
            else:
                out = im.resize((86, 86), Image.ANTIALIAS)
                captcha = out.convert('RGB')
                # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
        # 确定是两个大轮廓
        elif count_contours == 2:
            central_xy = []
            for cnt in contours:
                rect = cv2.minAreaRect(cnt)
                box = cv2.boxPoints(rect)  # 获取最小外接矩形的4个顶点
                box = np.int0(box)
                # print(box.ravel())
                # print(box)
                # 绘制最小外界矩
                for i in range(4):
                    cv2.line(img, tuple(box[i]), tuple(box[(i + 1) % 4]), (0, 255, 255))  # 5
                # 矩形中心点位置
                # print("最小外界矩形中心点位置xy",cv2.minAreaRect(cnt)[0])
                central_xy.append(cv2.minAreaRect(cnt)[0])
            # print(central_xy)
            dx = abs(central_xy[1][0] - central_xy[0][0])
            dy = abs(central_xy[1][1] - central_xy[0][1])
            # 横
            im = Image.open(imagepath)
            if dx > dy:
                width = random.randrange(86, 96)
                height = random.randrange(76, 86)
                out = im.resize((width, height), Image.ANTIALIAS)
                captcha = out.convert('RGB')
                # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
            else:
                height = random.randrange(86, 96)
                width = random.randrange(76, 86)
                out = im.resize((width, height), Image.ANTIALIAS)
                captcha = out.convert('RGB')
                # cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png', captcha)
                captcha.save(r"E:\rect_angle_test" + "\\" + str(name) + 'resize.png')
        else:  # 3个轮廓
            print("异常，剔除小区域后还有三个轮廓")
        # 保存绘制矩形后的图片
        cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + "remove_minAreaRectimg.png", img)
print("over")
