"""
@Time ： 2021/6/1 22:56
@Auth ： wangbooming
@File ：sort_floder.py
@IDE ：PyCharm
"""
import os
import os.path
rootdir = r"E:\MN_datasheet\new_data_cyclegan\new_data_cyclegan_MN_NBUD_select_all_hu\MN_gan_generate_all_select_resize/" #末尾斜杠不要丢
files = os.listdir(rootdir)
b=0
for name in files:
    a=os.path.splitext(name)
    # print(a[0])
    # newname = str(b) + "_" +'.jpg'
    newname = str(b) + '.jpg'
    b = b + 1
    os.rename(rootdir+name,rootdir+newname)