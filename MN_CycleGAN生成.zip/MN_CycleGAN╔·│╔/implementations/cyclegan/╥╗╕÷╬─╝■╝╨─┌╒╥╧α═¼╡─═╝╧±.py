# -*- coding: utf-8 -*-
"""
@Time ： 2022/1/10 21:44
@Auth ： wongbooming
@File ：一个文件夹内找相同的图像.py
@Explain :
"""

import os, cv2
from skimage.metrics import structural_similarity as sk_cpt_ssim
import numpy as np
import time
from PIL import Image, ImageChops


# 采用SSIM进行对比，速度会较慢
def found_same_img(path):
    dir_list = []
    for img_name in os.listdir(path):
        img_dir = path + img_name
        dir_list.append(img_dir)
    print(len(dir_list))
    # for No, img_dir in enumerate(dir_list):
    img = cv2.imread(path + 'c0208a167f9a12a5905dcc2f39af8cc.png')
    img = cv2.resize(img, dsize=(50, 50))
    # print(No)
    i = 0
    for other_img_dir in dir_list:
        i += 1
        other_img = cv2.imread(other_img_dir)
        other_img = cv2.resize(other_img, dsize=(50, 50))
        ssim = sk_cpt_ssim(img, other_img, multichannel=True)
        if str(ssim) == str(1.0):
            print('----', other_img_dir)
    # print('次数:',i)


# 采用PIL中的Imagecrops进行对比，速度会快上很多
def found_same_img_2(path):
    dir_list = []
    for img_name in os.listdir(path):
        img_dir = path + img_name
        dir_list.append(img_dir)
    print('共：', len(dir_list), '张')
    for No, img_dir in enumerate(dir_list):
        # start=time.time()
        img = Image.open(img_dir).resize((100, 100))
        i = 0
        for other_img_dir in dir_list[No + 1:]:
            i += 1
            # other_img=cv2.imread(other_img_dir)
            other_img = Image.open(other_img_dir).resize((100, 100))
            # print(img_dir,other_img_dir)
            try:
                diff = ImageChops.difference(img, other_img)
                if diff.getbbox() is None:
                    print('Same:', img_dir, '----', other_img_dir)
            except:
                print('Error，图片不匹配：', img_dir, '----', other_img_dir)
                continue
        # finish=time.time()
        # print(No,'  Time:',round((finish-start),2))
        print('次数:', i)


if __name__ == '__main__':
    path = r'E:\trainingrecords\GAN\new20211228\NBUD2NBUD\BN2BN_new_batch=16_res=10\images\\'
    found_same_img(path)
