# -*- coding: utf-8 -*-
"""
@Time ： 2021/8/18 22:48
@Auth ： wongbooming
@File ：computer_hsv.py
@Explain :
"""
import cv2
import numpy as np
import os
from numpy import *

def main(path):

    H_list = []
    S_list = []
    V_list = []
    result = []

    for root, dirs, files in os.walk(path):
        for file in files:
            if file[-1]=='g':
                print(file)
                img1 = cv2.imread(os.path.join(path, file),
                                  cv2.IMREAD_COLOR)
                HSV1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
                aH1, aS1, aV1 = cv2.split(HSV1)
                H1 = np.array(aH1).flatten()    # 6175403
                S1 = np.array(aS1).flatten()    # 5411094
                V1 = np.array(aV1).flatten()    # 8037177

                mean_H = H1.mean()
                mean_S = S1.mean()
                mean_V = V1.mean()
                H_list.append(mean_H)
                S_list.append(mean_S)
                V_list.append(mean_V)

    result.append(mean(H_list))
    result.append(mean(S_list))
    result.append(mean(V_list))

    return result


"""

微核有染色质： [129.40541393204077, 115.86681180254493, 164.73510506984587]
微核无染色质： [136.3201217908249, 92.54113634484729, 166.6658869197932]

核芽有染色质： [131.39486762152777, 115.91344992897727, 165.92092605744946]
核芽无染色质： [137.22424789546997, 96.94161443192829, 167.0391293705588]

GAN刚刚生成的初步迭代的那些图计算： [113.6691683604336, 159.24767784552844, 166.67396680216802]
"""

if __name__ == '__main__':
    path = r"E:\Targetdetection_model\PyTorch-GAN-master\implementations\cyclegan\images\computer_hsv"
    result = main(path)
    print(result)
