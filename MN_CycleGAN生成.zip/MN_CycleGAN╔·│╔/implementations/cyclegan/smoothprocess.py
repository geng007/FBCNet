"""
@Time ： 2021/6/1 15:40
@Auth ： wangbooming
@File ：smoothprocess.py
@IDE ：PyCharm
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
#   读取图片
img = cv2.imread(r'E:\MN_datasheet\cyclegan_data\BN\test\B\cut_img_good_6_16216_NBUD.jpg')

#   直方图
hist = cv2.calcHist([img], [0], None, [256], [0, 255])
plt.plot(hist, color='b')
plt.show()
#   滤波
result_median = cv2.medianBlur(img, 9)
result_gaussian = cv2.GaussianBlur(img, (9, 9), 0)
result_blur = cv2.blur(img, (9, 9))
#   显示图形
titles = ['Source Image', 'result_median', 'result_gaussian', 'result_blur']
images = [img, result_median, result_gaussian, result_blur]
for i in range(4):
    plt.subplot(1, 4, i + 1), plt.imshow(images[i], 'gray')
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([])
plt.show()