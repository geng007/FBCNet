
from models import GeneratorResNet

import os

import torchvision
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid

from torch.utils.data import DataLoader
from torch.autograd import Variable

from models import *
from datasets import *
from utils import *

import torch


def to_img(x):
    out = (x + 1) * 0.5
    out = out.clamp(0, 1)
    out = out.view(-1, 3, 96, 96)  # 大小取决于generate源代码中的大小
    return out

def main():
    z_dimension=100
    input_shape = (3,96,96)
    G_AB = GeneratorResNet(input_shape,10).cuda()
    # generate=torch.load("G_test.pkl") # 源程序
    G_AB.load_state_dict(torch.load(r"E:\trainingrecords\GAN\new20211228\NBUD2NBUD\BN2BN_new_batch=16_res=10\G_AB_1040.pth"))

    Tensor = torch.cuda.FloatTensor

    # Image transformations
    transforms_ = [
        transforms.Resize(int(96 * 1.12), Image.BICUBIC),   # 修改之后影像图像质量，大小不变
        # transforms.Resize(int(96 * 2), Image.BICUBIC),
        transforms.RandomCrop((96, 96)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ]
    # Test data loader
    val_dataloader = DataLoader(
        ImageDataset("../../data/%s" % "MN2MN", transforms_=transforms_, unaligned=True, mode="test"),
        # ImageDataset(r"E:\Targetdetection_model\PyTorch-GAN-master\implementations\cyclegan\test_MN2MN_test\0", transforms_=transforms_, unaligned=True, mode="test"),
        batch_size=3,
        shuffle=False,
        num_workers=1,
    )
    def sample_images(epoch):
        """Saves a generated sample from the test set"""
        imgs = next(iter(val_dataloader))
        G_AB.eval()
        real_A = Variable(imgs["A"].type(Tensor))
        fake_B = G_AB(real_A)

        # Arange images along x-axis
        for i in range(fake_B.size(0)):
            os.makedirs("test_MN2MN_test", exist_ok=True)
            torchvision.utils.save_image(to_img(fake_B[i, :, :, :]), 'test_MN2MN_test/{}.jpg'.format((epoch * 5) + i))
        real_A = make_grid(real_A, nrow=5, normalize=True)
        fake_B = make_grid(fake_B, nrow=5, normalize=True)
        # Arange images along y-axis
        image_grid = torch.cat((real_A, fake_B), 1)
        os.makedirs("test_MN2MN_grid_test", exist_ok=True)
        save_image(image_grid,"test_MN2MN_grid_test/%d.jpg" % epoch)
    # 多次生成
    for epoch in range(3):
        sample_images(epoch)
    print("over")


if __name__ == '__main__':
    main()
