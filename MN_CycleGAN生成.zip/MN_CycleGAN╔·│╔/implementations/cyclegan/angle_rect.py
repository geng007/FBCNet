"""
@Time ： 2021/6/12 16:01
@Auth ： wangbooming
@File ：angle_rect.py
@IDE ：PyCharm
"""
'''
单纯计算矩形偏移角度
'''
import cv2
import numpy as np

name = 309
imagepath = r"E:\rect_angle_test" + "\\" + str(name) + ".jpg"
img = cv2.imread(imagepath, 1)

# 把图片转换为灰度模式
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# 中值滤波
blur = cv2.medianBlur(gray, 3)  # 模板大小3*3
# 二值化
# ret,thresh = cv2.threshold(blur, 122, 255, cv2.THRESH_BINARY)
# 保存图片
t, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
# 黑白颠倒，不然计算轮廓面积好像有问题
t, otsu_true = cv2.threshold(otsu, 0, 255, cv2.THRESH_BINARY_INV)
cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + 'char_after_bin.png', otsu_true)
# imagepath = 'char_after_bin.png'
# img = cv2.imread(imagepath, -1)
contours, _ = cv2.findContours(otsu_true, 2, 2)

print(len(contours))
img = cv2.imread(imagepath, 1)
for cnt in contours:

    # 最小外界矩形的宽度和高度
    width, height = cv2.minAreaRect(cnt)[1]
    print(width * height)
    if width * height > 100:
        # 最小的外接矩形
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)  # 获取最小外接矩形的4个顶点
        box = np.int0(box)
        print(box.ravel())
        print(box)

        # if 0 not in box.ravel():

        # 绘制最小外界矩

        for i in range(4):
            cv2.line(img, tuple(box[i]), tuple(box[(i + 1) % 4]), (0, 255, 255))  # 5
        # cv2.waitKey()
        # 旋转角度
        theta = cv2.minAreaRect(cnt)[2]
        # 矩形中心点位置
        print("最小外界矩形中心点位置xy", cv2.minAreaRect(cnt)[0])
        # 矩形长和宽
        print("最小外界矩形长和宽", cv2.minAreaRect(cnt)[1])
        print(theta)
        # if abs(theta) <= 45:
        print('图片的旋转角度为%s.' % theta)
        angle = theta
cv2.imwrite(r"E:\rect_angle_test" + "\\" + str(name) + "minAreaRectimg.png", img)

# # 仿射变换,对图片旋转angle角度
# h, w = img.shape
# center = (w//2, h//2)
# M = cv2.getRotationMatrix2D(center, angle, 1.0)
# rotated = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

# 保存旋转后的图片
# cv2.imwrite('after_rotated.png', rotated)
