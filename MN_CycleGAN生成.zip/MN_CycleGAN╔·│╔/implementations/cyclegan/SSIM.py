"""
@Time ： 2021/6/6 19:04
@Auth ： wangbooming
@File ：SSIM.py.py
@IDE ：PyCharm
"""
# cyclegan 生成的图像质量评价,系列文件综合比较
# MSE
import cv2
import os
from sklearn.metrics import mean_squared_error
from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio
import matplotlib.pyplot as plt

floder_classical_path = r'E:\MN_datasheet\new_data\MN_average_select_96'
floder_generate_path = r'E:\MN_datasheet\new_data_cyclegan\MN_gan_generate_96_test_plot_SSIM\68'
floder_original_path = r'E:\MN_datasheet\new_data_cyclegan\MN_gan\68'

MSE_generate_mean, PSNR_generate_mean, ssim_generate_mean = [], [], []
MSE_original_mean, PSNR_original_mean, ssim_original_mean = [], [], []

for root, dirs, files in os.walk(floder_generate_path):
    for file in files:
        img_generate_path = os.path.join(root, file)
        # print(img_generate_path)
        img_generate = cv2.imread(img_generate_path)
        img_generate = cv2.cvtColor(img_generate, cv2.COLOR_RGB2GRAY)
        MSE_generate, PSNR_generate, ssim_generate = [], [], []
        for root_, dirs_, files_ in os.walk(floder_classical_path):
            for file_ in files_:
                img_classical_path = os.path.join(root_, file_)
                img_classical = cv2.imread(img_classical_path)
                img_classical = cv2.cvtColor(img_classical, cv2.COLOR_RGB2GRAY)

                MSE_generate.append(mean_squared_error(img_classical, img_generate))
                PSNR_generate.append(peak_signal_noise_ratio(img_classical, img_generate))
                ssim_generate.append(
                    structural_similarity(img_classical, img_generate, data_range=255))  # 对比的两张图size应该相同
        # MSE_generate_mean.append(sum(MSE_generate) / (len(MSE_generate)))
        PSNR_generate_mean.append(sum(PSNR_generate) / (len(PSNR_generate)))
        # ssim_generate_mean.append(sum(ssim_generate) / (len(ssim_generate)))
for root, dirs, files in os.walk(floder_original_path):
    for file in files:
        img_original_path = os.path.join(root, file)
        # print(img_original_path)
        img_original = cv2.imread(img_original_path)
        img_original = cv2.cvtColor(img_original, cv2.COLOR_RGB2GRAY)
        MSE_original, PSNR_original, ssim_original = [], [], []
        for root_, dirs_, files_ in os.walk(floder_classical_path):
            for file_ in files_:
                img_classical_path = os.path.join(root_, file_)
                img_classical = cv2.imread(img_classical_path)
                img_classical = cv2.cvtColor(img_classical, cv2.COLOR_RGB2GRAY)

                MSE_original.append(mean_squared_error(img_classical, img_original))
                PSNR_original.append(peak_signal_noise_ratio(img_classical, img_original))
                ssim_original.append(
                    structural_similarity(img_classical, img_original, data_range=255))  # 对比的两张图size应该相同
        # MSE_original_mean.append(sum(MSE_original) / (len(MSE_original)))
        PSNR_original_mean.append(sum(PSNR_original) / (len(PSNR_original)))
        # ssim_original_mean.append(sum(ssim_original) / (len(ssim_original)))

x = [i for i in range(32)]  # 横坐标

# plt.plot(x, MSE_generate_mean)
# plt.plot(x, MSE_original_mean)
# 峰值信噪比，生成的图像更清晰
plt.title(u'The PSNR comparison of 32 randomly selected images')
plt.xlabel('images')  # 设置x，y轴的标签
plt.ylabel('PSNR')
plt.plot(x, PSNR_generate_mean,color='red',linewidth=1.0,linestyle='--',label="PSNR_generate")
plt.plot(x, PSNR_original_mean,color='black',linewidth=1.0,linestyle='solid',label="PSNR_original")
plt.legend(loc=0,ncol=2)    # 图例及位置： 1右上角，2 左上角 loc函数可不写 0为最优 ncol为标签有几列
# plt.plot(x, ssim_generate_mean)   # 结构相似度
# plt.plot(x, ssim_original_mean)
plt.savefig("max_68_PSNR.png")
plt.show()