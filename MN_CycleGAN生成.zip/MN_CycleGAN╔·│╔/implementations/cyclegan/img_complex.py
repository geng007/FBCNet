"""
@Time ： 2021/6/1 15:11
@Auth ： wangbooming
@File ：img_complex.py
@IDE ：PyCharm
"""
import os
import random
from PIL import Image

'''
gan生成的小图拼接成大图
'''


def main():
    # width_i = 100
    # height_i = 100
    row_max = random.randrange(3, 5, 1)
    line_max = random.randrange(3, 5, 1)
    all_path = list()
    num = 3
    pic_max = line_max * row_max
    dir_name = r"E:\MN_datasheet\new_data_cyclegan\new_data_cyclegan_MN_NBUD_select_all_hu\NBUD_gan_generate_all_select"
    save_dir = r"E:\MN_datasheet\new_data_cyclegan\new_data_cyclegan_MN_NBUD_select_all_hu\NBUD_gan_generate_all_select_label"
    # root文件夹的路径  dirs 路径下的文件夹列表  files路径下的文件列表
    for root, dirs, files in os.walk(dir_name):
        for file in files:
            if "jpg" in file:  # 子串在母串里面不
                # print(file)
                all_path.append(os.path.join(root, file))
    # all_path获取每张图片的绝对路径,0,1,10,11,12...2,20,21
    # 修改排序,test为分隔符：E:\\MN_datasheet\\new_data_cyclegan\\test\\0.jpg'
    # print(all_path)
    all_path.sort(key=lambda x: int(x.split('select\\')[1].split('.jpg')[0]))
    print("all_path数量：", len(all_path))
    ranorder_list = []
    for num in range((len(all_path)) // (3 * 3)):
        row_max = random.randrange(3, 5, 1)
        line_max = row_max
        ranorder = random.randrange(0, 23800, 1)
        ranorder_list.append(ranorder)
        width_i = random.randrange(66, 100)  # 需要注意row_max,可能会超限
        height_i = random.randrange(66, 100)
        try:
            toImage = Image.open('good_1_141.jpg', mode='r')
        except:
            toImage = Image.new('RGB', (512, 512), "pink")
        all_width, all_height = toImage.size
        order = num * row_max * line_max
        if order + row_max * line_max > len(all_path):
            # print("超限")
            break
        else:
            row_list = [0]
            line_list = [0]
            for i in range(row_max):
                line_list = [0]
                for j in range(line_max):
                    # 每次打开图片绝对路路径列表的第一张图片
                    pic_fole_head = Image.open(all_path[order])
                    # 获取图片的尺寸

                    # 按照指定的尺寸，给图片重新赋值，<PIL.Image.Image image mode=RGB size=200x200 at 0x127B7978>
                    tmppic = pic_fole_head.resize((width_i, height_i))
                    # 计算每个图片的左上角的坐标点(0, 0)，(0, 200)，(0, 400)，(200, 0)，(200, 200)。。。。(400, 400)
                    # loc = (int((i % line_max * width_i)+2*(i+1)), int((j % line_max * height_i)+2*(j+1)))   # 5张
                    # loc = (int((i % line_max * width_i) + 22 * (i + 1)), int((j % line_max * height_i) + 22 * (j + 1)))   #四张
                    loc_row = random.randrange(max(row_list),
                                               (all_width - row_max * width_i) // (row_max + 1), 1)
                    loc_line = random.randrange(max(line_list),
                                                (all_height - line_max * height_i) // (line_max + 1), 1)
                    left_x = int((i % line_max * width_i) + loc_row * (i + 1))
                    left_y = int((j % line_max * height_i) + loc_line * (j + 1))
                    loc = (left_x, left_y)
                    row_list.append(loc_row)
                    line_list.append(loc_line)
                    # print(loc)
                    # print("第{}张图的存放位置".format(order),loc)
                    # 写入标签信息
                    # 坐标信息
                    center_x = (left_x + width_i // 2) / 512
                    center_y = (left_y + height_i // 2) / 512
                    w = width_i / 512
                    h = height_i / 512
                    with open(save_dir + "//" + "gan_nbud_" + str(num) + '.txt', 'a+') as f:  # 写入日志信息
                        f.write("2" + " " + str(center_x) + " " + str(center_y) + " " +
                                str(w) + " " + str(h) + "\n")
                    toImage.paste(tmppic, loc)
                    order = order + 1
        toImage.save(r"E:\MN_datasheet\new_data_cyclegan\new_data_cyclegan_MN_NBUD_select_all_hu"
                     r"\NBUD_gan_generate_all_select_complex "
                     + "\\" + "gan_nbud_" + str(num) + ".jpg")


if __name__ == '__main__':
    main()
