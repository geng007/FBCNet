# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/1 11:31
@Auth ： wongbooming
@File ：test_128.py
@Explain :
"""

from torch.utils.data import DataLoader
from torch.autograd import Variable
from torchvision import transforms
from models import *
from datasets import *
from utils import *
import torch
import torchvision


def to_img(x):
    out = (x + 1) * 0.5
    out = out.clamp(0, 1)
    out = out.view(-1, 3, 128, 128)  # 大小取决于generate源代码中的大小
    return out


def main():
    z_dimension = 100
    input_shape = (3, 128, 128)
    G_AB = GeneratorResNet(input_shape, 4).cuda()
    # generate=torch.load("G_test.pkl") # 源程序
    G_AB.load_state_dict(torch.load(r"E:\trainingrecords\GAN\NPBs2NPBs\G_AB_290.pth"))



    def sample_images():
        """Saves a generated sample from the test set"""
        path = r'E:\MN_datasheet\hybrid\NPBs_no_cytoplasm_select_128'
        # Tensor = torch.cuda.FloatTensor
        epoch = 0

        for filename in os.listdir(path):
            src_1 = cv2.imread(path + '\\' + filename)
            # imgs = next(iter(val_dataloader))
            G_AB.eval()
            # real_A = Variable(imgs["A"].type(Tensor))
            # src_1 = torch.from_numpy(src_1).unsqueeze(0).float
            # src_1 = torch.from_numpy(src_1)
            transform2 = transforms.Compose([transforms.ToTensor()])
            src_1 = transform2(src_1)
            # src_1 = torch.from_numpy(src_1)
            real_A = Variable(src_1)
            real_A = real_A.unsqueeze(0).cuda()
            fake_B = G_AB(real_A)

            # save_image(fake_B, "generate_53-20210607_cyclegan_300epo_MN2MN/%d.jpg" % epoch)
            epoch += 1
            # Arange images along x-axis
            for i in range(fake_B.size(0)):
                os.makedirs(r"E:\MN_datasheet\hybrid\NPBs_no_cytoplasm_select_cyclegan", exist_ok=True)
                torchvision.utils.save_image(to_img(fake_B[i, :, :, :]),
                                             r'E:\MN_datasheet\hybrid\NPBs_no_cytoplasm_select_cyclegan\{}.jpg'.format((epoch) + i))


    sample_images()
    print("over")


if __name__ == '__main__':
    main()
