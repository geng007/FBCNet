# -*- coding: utf-8 -*-
"""
@Time ： 2021/8/17 21:11
@Auth ： wongbooming
@File ：color_loss.py
@Explain :
"""

import math
import cv2
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.mlab as mlab



def color_loss():

    img1 = cv2.imread('compare_images/2450.png',
                      cv2.IMREAD_COLOR)

    HSV1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
    aH1, aS1, aV1 = cv2.split(HSV1)
    H1 = np.array(aH1).flatten()    # 6175403
    S1 = np.array(aS1).flatten()    # 5411094
    V1 = np.array(aV1).flatten()    # 8037177
    print("*******")
    print("H1:", H1)
    print("S1:", S1)
    print("V1:", V1)
    img2 = cv2.imread('compare_images/2550.png',
                      cv2.IMREAD_COLOR)

    HSV2 = cv2.cvtColor(img2, cv2.COLOR_BGR2HSV)
    aH2, aS2, aV2 = cv2.split(HSV2)
    H2 = np.array(aH2).flatten()
    S2 = np.array(aS2).flatten()
    V2 = np.array(aV2).flatten()
    print("*******")
    print("H2:", H2)
    print("S2:", S2)
    print("V2:", V2)

    R = 100.0
    angle = 30.0
    h = R * math.cos(angle / 180 * math.pi)
    r = R * math.sin(angle / 180 * math.pi)

    sum = 0.0
    for i in range(0, len(H1)):
        x1 = r * V1[i] * S1[i] * math.cos(H1[i] / 180.0 * math.pi)
        y1 = r * V1[i] * S1[i] * math.sin(H1[i] / 180.0 * math.pi)
        z1 = h * (1 - V1[i])

        x2 = r * V2[i] * S2[i] * math.cos(H2[i] / 180.0 * math.pi)
        y2 = r * V2[i] * S2[i] * math.sin(H2[i] / 180.0 * math.pi)
        z2 = h * (1 - V2[i])

        dx = x1 - x2
        dy = y1 - y2
        dz = z1 - z2

        sum = sum + dx * dx + dy * dy + dz * dz

    eucli_dean = math.sqrt(sum)
    eucli_dean /= 100000000
    return eucli_dean


if __name__ == '__main__':
    print(color_loss())

# 68136267.12262884; 62756821.61116336 有无染色质
# 34932565.73167801; 34280626.242800936 都有染色质
# 40057249.08531798; 32715148.457172513 都没有染色质

""""
生成图像对比
0-1：       440976595.4861594
0-2550：    342647416.90530324
2550-2500： 88640721.81273839
2450-2500： 92256011.58987367
"""