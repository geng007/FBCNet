import random
import time
import datetime
import sys

from torch.autograd import Variable
import torch
import numpy as np
import cv2
import math
from torchvision.utils import save_image

def color_loss(generate_image, img_true):
    img1 = cv2.cvtColor(np.asarray(generate_image), cv2.COLOR_RGB2BGR)

    HSV1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
    aH1, aS1, aV1 = cv2.split(HSV1)
    H1 = np.array(aH1).flatten()
    S1 = np.array(aS1).flatten()
    V1 = np.array(aV1).flatten()

    img2 = cv2.cvtColor(np.asarray(img_true), cv2.COLOR_RGB2BGR)
    HSV2 = cv2.cvtColor(img2, cv2.COLOR_BGR2HSV)
    aH2, aS2, aV2 = cv2.split(HSV2)
    H2 = np.array(aH2).flatten()
    S2 = np.array(aS2).flatten()
    V2 = np.array(aV2).flatten()

    R = 100.0
    angle = 30.0
    h = R * math.cos(angle / 180 * math.pi)
    r = R * math.sin(angle / 180 * math.pi)

    sum = 0.0
    for i in range(0, len(H1)):
        x1 = r * V1[i] * S1[i] * math.cos(H1[i] / 180.0 * math.pi)
        y1 = r * V1[i] * S1[i] * math.sin(H1[i] / 180.0 * math.pi)
        z1 = h * (1 - V1[i])

        x2 = r * V2[i] * S2[i] * math.cos(H2[i] / 180.0 * math.pi)
        y2 = r * V2[i] * S2[i] * math.sin(H2[i] / 180.0 * math.pi)
        z2 = h * (1 - V2[i])

        dx = x1 - x2
        dy = y1 - y2
        dz = z1 - z2

        sum = sum + dx * dx + dy * dy + dz * dz

    eucli_dean = math.sqrt(sum)
    eucli_dean /= 100000000
    return eucli_dean

class myLoss(torch.nn.Module):
    def __init__(self, generate, original):
        super().__init__()
        self.generate = generate
        self.original = original

    def forward(self):
        loss = color_loss(self.generate, self.original)
        return loss


class ReplayBuffer:
    def __init__(self, max_size=50):
        assert max_size > 0, "Empty buffer or trying to create a black hole. Be careful."
        self.max_size = max_size
        self.data = []

    def push_and_pop(self, data):
        to_return = []
        for element in data.data:
            element = torch.unsqueeze(element, 0)
            if len(self.data) < self.max_size:
                self.data.append(element)
                to_return.append(element)
            else:
                if random.uniform(0, 1) > 0.5:
                    i = random.randint(0, self.max_size - 1)
                    to_return.append(self.data[i].clone())
                    self.data[i] = element
                else:
                    to_return.append(element)
        return Variable(torch.cat(to_return))


class LambdaLR:
    def __init__(self, n_epochs, offset, decay_start_epoch):
        assert (n_epochs - decay_start_epoch) > 0, "Decay must start before the training session ends!"
        self.n_epochs = n_epochs
        self.offset = offset
        self.decay_start_epoch = decay_start_epoch

    def step(self, epoch):
        return 1.0 - max(0, epoch + self.offset - self.decay_start_epoch) / (self.n_epochs - self.decay_start_epoch)
