# -*- coding: utf-8 -*-
"""
@Time ： 2021/9/4 15:02
@Auth ： wongbooming
@File ：computer_hsv_paper.py
@Explain :
"""

import cv2
import numpy as np
import os
from numpy import *
from pylab import *

mpl.rcParams['font.sans-serif'] = ['SimHei']


def hsv(path_no):
    H_list_no = []
    S_list_no = []
    V_list_no = []
    result_no = []

    for root, dirs, files in os.walk(path_no):
        for file in files:
            if file[-1] == 'g':
                print(file)
                file = file.replace(' - 副本', '')
                img1 = cv2.imread(os.path.join(path_no, file),
                                  cv2.IMREAD_COLOR)
                HSV1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
                aH1, aS1, aV1 = cv2.split(HSV1)
                H1 = np.array(aH1).flatten()  # 6175403
                S1 = np.array(aS1).flatten()  # 5411094
                V1 = np.array(aV1).flatten()  # 8037177

                mean_H = H1.mean()
                mean_S = S1.mean()
                mean_V = V1.mean()
                H_list_no.append(mean_H)
                S_list_no.append(mean_S)
                V_list_no.append(mean_V)
    return H_list_no, S_list_no, V_list_no


def main(path_no, path_yes, path_gan):
    H_list_no, S_list_no, V_list_no = hsv(path_no)
    H_list_yes, S_list_yes, V_list_yes = hsv(path_yes)
    H_list_gan, S_list_gan, V_list_gan = hsv(path_gan)

    x_axis_data = list(range(0, 50))
    # y_axis_data =

    # plot中参数的含义分别是横轴值，纵轴值，线的形状，颜色，透明度,线的宽度和标签
    plt.plot(x_axis_data, H_list_no, 'ro-', color='#4169E1', alpha=0.8, linewidth=1, label='H_A')
    plt.plot(x_axis_data, H_list_yes, 'ro-', color='#FFB344', alpha=0.8, linewidth=1, label='H_B')
    plt.plot(x_axis_data, H_list_gan, 'ro-', color='#008B8B', alpha=0.8, linewidth=1, label='H_G')
    # plt.plot(x_axis_data, S_list_no, 'ro-', color='#4169E1', alpha=0.8, linewidth=1, label='S_no')
    # plt.plot(x_axis_data, S_list_yes, 'ro-', color='#4169E1', alpha=0.8, linewidth=1, label='S_yes')
    # plt.plot(x_axis_data, V_list_no, 'ro-', color='#3B0000', alpha=0.8, linewidth=1, label='V_no')
    # plt.plot(x_axis_data, V_list_yes, 'ro-', color='#3B0000', alpha=0.8, linewidth=1, label='V_yes')
    # 显示标签，如果不加这句，即使在plot中加了label='一些数字'的参数，最终还是不会显示标签
    plt.legend(loc="upper right")
    plt.xlabel('the Sampled images')
    plt.ylabel('H values')
    plt.title('H comparison of three kinds of images')
    # plt.savefig(r'E:\NucleuiDetNet\H_comparison_3cls.png')  # 保存该图片
    plt.show()
    # result_no.append(mean(H_list_no))
    # result_no.append(mean(S_list_no))
    # result_no.append(mean(V_list_no))
    #
    # return result_no


"""

微核有染色质： [129.40541393204077, 115.86681180254493, 164.73510506984587]
微核无染色质： [136.3201217908249, 92.54113634484729, 166.6658869197932]

核芽有染色质： [131.39486762152777, 115.91344992897727, 165.92092605744946]
核芽无染色质： [137.22424789546997, 96.94161443192829, 167.0391293705588]

GAN刚刚生成的初步迭代的那些图计算： [113.6691683604336, 159.24767784552844, 166.67396680216802]
"""

if __name__ == '__main__':
    path = r"E:\NucleuiDetNet\hsv_compare\MN2MN\A"
    path2 = r"E:\NucleuiDetNet\hsv_compare\MN2MN\B"
    path3 = r'E:\NucleuiDetNet\hsv_compare\MN2MN\cyclegan'
    main(path_no=path, path_yes=path2, path_gan=path3)
    # print(result)
