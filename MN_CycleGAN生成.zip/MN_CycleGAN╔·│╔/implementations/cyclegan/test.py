
from models import *
from datasets import *
from utils import *
import torch
import torchvision


def to_img(x):
    out = (x + 1) * 0.5
    out = out.clamp(0, 1)
    out = out.view(3, 96, 96)  # 大小取决于generate源代码中的大小
    return out


def main():
    z_dimension = 100
    input_shape = (3, 96, 96)
    G_AB = GeneratorResNet(input_shape, 10).cuda()
    # generate=torch.load("G_test.pkl") # 源程序
    G_AB.load_state_dict(torch.load(r"E:\trainingrecords\GAN\single2single\saved_models\G_AB_280.pth"))


    """Saves a generated sample from the test set"""
    path = r'E:\MN_datasheet\single_nucleus\extract_images_A_96'
    # Tensor = torch.cuda.FloatTensor

    for filename in os.listdir(path):
        src_1 = cv2.imread(path + '\\' + filename)
        name = filename.split('.')[0]
        # imgs = next(iter(val_dataloader))
        G_AB.eval()
        # real_A = Variable(imgs["A"].type(Tensor))
        # src_1 = torch.from_numpy(src_1).unsqueeze(0).float
        # src_1 = torch.from_numpy(src_1)
        transform2 = transforms.Compose([transforms.ToTensor()])
        src_1 = transform2(src_1)
        # src_1 = torch.from_numpy(src_1)
        real_A = Variable(src_1)
        real_A = real_A.unsqueeze(0).cuda()
        fake_B = G_AB(real_A)

        # fake_B = make_grid(fake_B, nrow=1, normalize=True)

        # save_image(fake_B, r"E:\MN_datasheet\Data_BC\4classes\NPBs_GAN\gan_npbs_%d.jpg" % epoch)
        # Arange images along x-axis
        for i in range(fake_B.size(0)):
            os.makedirs(r"E:\MN_datasheet\single_nucleus\extract_images_A_96_generate", exist_ok=True)
            torchvision.utils.save_image(to_img(fake_B[i, :, :, :]),
                                         r'E:\MN_datasheet\single_nucleus\extract_images_A_96_generate/gan_{}.jpg'.
                                         format(name))

if __name__ == '__main__':
    main()
